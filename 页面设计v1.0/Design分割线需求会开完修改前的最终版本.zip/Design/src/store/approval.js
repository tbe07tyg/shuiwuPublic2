import { defineStore } from 'pinia'
import { ref } from 'vue'

/**
 * 立项流程节点顺序
 */
export const nodeOrder = ['materials', 'review', 'decision', 'inquiry']

/**
 * 立项项目全局store
 * @see 立项中心与流程自动流转方案.txt
 */
export const useApprovalStore = defineStore('approval', () => {
  /**
   * 立项项目清单（全局响应式）
   * @type {import('vue').Ref<Array<{id:string,title:string,applicant:string,status:string,budget:number,requirementId:string,node:string,nodeHistory?:Array}>}>
   */
  const approvalList = ref([
    { id: 'A001', title: '智能水表项目立项', applicant: '王五', status: '待审批', budget: 200, requirementId: 'REQ001', node: 'materials' },
    { id: 'A002', title: '管网监测优化立项', applicant: '赵六', status: '已通过', budget: 150, requirementId: 'REQ002', node: 'review' },
    { id: 'A003', title: '水厂自动化改造', applicant: '李明', status: '待审批', budget: 180, requirementId: 'REQ001', node: 'decision' },
    { id: 'A004', title: '管网智能监控平台', applicant: '王强', status: '已通过', budget: 220, requirementId: 'REQ002', node: 'inquiry' }
  ])

  /**
   * 推进项目到下一个流程节点
   * @param {string} projectId 项目ID
   * @returns {string|null} 新节点key，或null（流程已结束）
   */
  function submitAndNext(projectId) {
    const project = approvalList.value.find(p => p.id === projectId)
    if (!project) return null
    const idx = nodeOrder.indexOf(project.node)
    if (idx < nodeOrder.length - 1) {
      project.node = nodeOrder[idx + 1]
      if (!project.nodeHistory) project.nodeHistory = []
      project.nodeHistory.push({ node: project.node, time: Date.now() })
      return project.node
    } else {
      return null // 流程已结束
    }
  }

  return {
    approvalList,
    submitAndNext
  }
}) 