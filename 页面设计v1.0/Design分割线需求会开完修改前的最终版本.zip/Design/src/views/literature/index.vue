<template>
  <div>文献管理页面</div>
</template> 