<template>
  <div style="padding: 32px;">
    <h2>方案1</h2>
    <Scheme1 />
    <h2 style="margin-top:32px;">方案2</h2>
    <Scheme2 />
    <h2 style="margin-top:32px;">方案3</h2>
    <Scheme3 />
  </div>
</template>
<script setup>
import Scheme1 from './方案1.vue'
import Scheme2 from './方案2.vue'
import Scheme3 from './方案3.vue'
</script> 