<template>
  <div class="meeting-management">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">
          <TeamOutlined />
          交流座谈会
        </h1>
        <p class="page-desc">组织和管理项目调研中的交流座谈会，收集各方意见和建议</p>
      </div>
      <div class="header-actions">
        <a-button type="primary" @click="showAddMeetingModal = true">
          <PlusOutlined />
          新建座谈会
        </a-button>
        <a-button @click="exportMeetings">
          <DownloadOutlined />
          导出会议纪要
        </a-button>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-section">
      <a-row :gutter="16">
        <a-col :span="6">
          <a-card>
            <a-statistic
              title="总座谈会数"
              :value="meetings.length"
              :value-style="{ color: '#234fa2' }"
            >
              <template #prefix>
                <TeamOutlined />
              </template>
            </a-statistic>
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card>
            <a-statistic
              title="本月已举办"
              :value="getMonthlyMeetings()"
              :value-style="{ color: '#52c41a' }"
            >
              <template #prefix>
                <CheckCircleOutlined />
              </template>
            </a-statistic>
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card>
            <a-statistic
              title="待举办"
              :value="getPendingMeetings()"
              :value-style="{ color: '#faad14' }"
            >
              <template #prefix>
                <ClockCircleOutlined />
              </template>
            </a-statistic>
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card>
            <a-statistic
              title="参与总人数"
              :value="getTotalParticipants()"
              :value-style="{ color: '#1890ff' }"
            >
              <template #prefix>
                <UserOutlined />
              </template>
            </a-statistic>
          </a-card>
        </a-col>
      </a-row>
    </div>

    <!-- 筛选区域 -->
    <div class="filter-section">
      <a-row :gutter="16">
        <a-col :span="16">
          <a-space size="middle">
            <a-select 
              v-model:value="filterStatus" 
              placeholder="会议状态" 
              style="width: 120px"
              @change="handleFilter"
            >
              <a-select-option value="">全部状态</a-select-option>
              <a-select-option value="筹备中">筹备中</a-select-option>
              <a-select-option value="进行中">进行中</a-select-option>
              <a-select-option value="已结束">已结束</a-select-option>
              <a-select-option value="已取消">已取消</a-select-option>
            </a-select>
            
            <a-select 
              v-model:value="filterType" 
              placeholder="会议类型" 
              style="width: 120px"
              @change="handleFilter"
            >
              <a-select-option value="">全部类型</a-select-option>
              <a-select-option value="专家咨询">专家咨询</a-select-option>
              <a-select-option value="用户访谈">用户访谈</a-select-option>
              <a-select-option value="技术交流">技术交流</a-select-option>
              <a-select-option value="需求讨论">需求讨论</a-select-option>
            </a-select>
            
            <a-range-picker 
              v-model:value="filterDateRange"
              placeholder="选择时间范围"
              @change="handleFilter"
            />
            
            <a-input-search
              v-model:value="searchKeyword"
              placeholder="搜索会议主题或参与者"
              style="width: 250px"
              @search="handleFilter"
            />
          </a-space>
        </a-col>
        <a-col :span="8">
          <div class="view-controls">
            <a-radio-group v-model:value="viewMode" @change="handleViewChange">
              <a-radio-button value="list">列表视图</a-radio-button>
              <a-radio-button value="calendar">日历视图</a-radio-button>
            </a-radio-group>
          </div>
        </a-col>
      </a-row>
    </div>

    <!-- 列表视图 -->
    <div class="meetings-list" v-if="viewMode === 'list'">
      <a-row :gutter="16">
        <a-col :span="24" v-for="meeting in filteredMeetings" :key="meeting.id">
          <div class="meeting-card">
            <div class="meeting-header">
              <div class="meeting-info">
                <h3 class="meeting-title">{{ meeting.title }}</h3>
                <div class="meeting-meta">
                  <a-tag :color="getStatusColor(meeting.status)">{{ meeting.status }}</a-tag>
                  <a-tag>{{ meeting.type }}</a-tag>
                  <span class="meeting-time">
                    <CalendarOutlined />
                    {{ meeting.scheduledDate }} {{ meeting.scheduledTime }}
                  </span>
                  <span class="meeting-location">
                    <EnvironmentOutlined />
                    {{ meeting.location }}
                  </span>
                </div>
              </div>
              <div class="meeting-actions">
                <a-button-group>
                  <a-button size="small" @click="viewMeetingDetail(meeting)">
                    <EyeOutlined />
                    查看详情
                  </a-button>
                  <a-button size="small" @click="editMeeting(meeting)" v-if="meeting.status !== '已结束'">
                    <EditOutlined />
                    编辑
                  </a-button>
                  <a-button size="small" @click="startMeeting(meeting)" v-if="meeting.status === '筹备中'">
                    <PlayCircleOutlined />
                    开始会议
                  </a-button>
                  <a-button size="small" @click="endMeeting(meeting)" v-if="meeting.status === '进行中'">
                    <StopOutlined />
                    结束会议
                  </a-button>
                </a-button-group>
              </div>
            </div>
            
            <div class="meeting-content">
              <div class="meeting-description">
                <p>{{ meeting.description }}</p>
              </div>
              
              <div class="meeting-participants">
                <div class="participants-section">
                  <h4>参与者 ({{ meeting.participants.length }}人)</h4>
                  <div class="participants-list">
                    <a-avatar-group :max-count="5">
                      <a-avatar v-for="participant in meeting.participants" :key="participant.id">
                        {{ participant.name.charAt(0) }}
                      </a-avatar>
                    </a-avatar-group>
                    <span class="more-participants" v-if="meeting.participants.length > 5">
                      +{{ meeting.participants.length - 5 }}
                    </span>
                  </div>
                </div>
                
                <div class="agenda-section">
                  <h4>议题 ({{ meeting.agenda.length }}项)</h4>
                  <div class="agenda-list">
                    <a-tag v-for="item in meeting.agenda.slice(0, 3)" :key="item.id" color="blue">
                      {{ item.title }}
                    </a-tag>
                    <span v-if="meeting.agenda.length > 3" class="more-agenda">
                      +{{ meeting.agenda.length - 3 }}项
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </a-col>
      </a-row>
    </div>

    <!-- 日历视图 -->
    <div class="calendar-view" v-else-if="viewMode === 'calendar'">
      <a-calendar v-model:value="selectedDate" @select="onCalendarSelect">
        <template #dateCellRender="{ current }">
          <div class="calendar-meetings">
            <div 
              v-for="meeting in getMeetingsByDate(current)" 
              :key="meeting.id"
              class="calendar-meeting-item"
              :class="`status-${meeting.status}`"
              @click="viewMeetingDetail(meeting)"
            >
              <div class="meeting-time">{{ meeting.scheduledTime }}</div>
              <div class="meeting-title">{{ meeting.title }}</div>
            </div>
          </div>
        </template>
      </a-calendar>
    </div>

    <!-- 空状态 -->
    <div v-if="filteredMeetings.length === 0" class="empty-state">
      <a-empty description="暂无座谈会数据">
        <a-button type="primary" @click="showAddMeetingModal = true">
          新建座谈会
        </a-button>
      </a-empty>
    </div>

    <!-- 新增/编辑座谈会弹窗 -->
    <MeetingModal
      v-model:visible="showAddMeetingModal"
      :meeting="currentMeeting"
      @save="saveMeeting"
    />

    <!-- 会议详情抽屉 -->
    <a-drawer
      v-model:open="showDetailDrawer"
      title="座谈会详情"
      width="800"
      placement="right"
    >
      <MeetingDetail
        v-if="selectedMeeting"
        :meeting="selectedMeeting"
        @edit="editMeeting"
        @start="startMeeting"
        @end="endMeeting"
      />
    </a-drawer>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { message } from 'ant-design-vue'
import dayjs from 'dayjs'
import {
  TeamOutlined,
  PlusOutlined,
  DownloadOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  UserOutlined,
  CalendarOutlined,
  EnvironmentOutlined,
  EyeOutlined,
  EditOutlined,
  PlayCircleOutlined,
  StopOutlined
} from '@ant-design/icons-vue'
import MeetingModal from '@/components/research/MeetingModal.vue'
import MeetingDetail from '@/components/research/MeetingDetail.vue'

/**
 * 响应式数据定义
 */
const meetings = ref([])
const filteredMeetings = ref([])
const showAddMeetingModal = ref(false)
const showDetailDrawer = ref(false)
const currentMeeting = ref(null)
const selectedMeeting = ref(null)
const viewMode = ref('list')
const selectedDate = ref(dayjs())

/**
 * 筛选条件
 */
const filterStatus = ref('')
const filterType = ref('')
const filterDateRange = ref([])
const searchKeyword = ref('')

/**
 * 新增需求数据
 */
const requirements = ref([
  { id: 'R001', name: '需求A' },
  { id: 'R002', name: '需求B' }
])
const selectedRequirement = ref()

/**
 * 初始化模拟数据
 */
function initMockData() {
  meetings.value = [
    {
      id: 'MTG001',
      title: '智能水质监测系统专家咨询会',
      description: '邀请行业专家对智能水质监测系统升级方案进行咨询和讨论',
      type: '专家咨询',
      status: '筹备中',
      scheduledDate: '2024-02-15',
      scheduledTime: '14:00-16:00',
      location: '会议室A',
      organizer: '张三',
      participants: [
        { id: 'P001', name: '李教授', role: '技术专家', organization: '清华大学' },
        { id: 'P002', name: '王工程师', role: '行业专家', organization: '水务集团' },
        { id: 'P003', name: '陈主任', role: '项目负责人', organization: '本公司' }
      ],
      agenda: [
        { id: 'A001', title: '技术方案介绍', duration: 30, speaker: '张三' },
        { id: 'A002', title: '专家意见收集', duration: 60, speaker: '李教授' },
        { id: 'A003', title: '方案优化讨论', duration: 30, speaker: '全体' }
      ],
      materials: [],
      notes: '',
      outcomes: [],
      createdAt: '2024-01-20'
    },
    {
      id: 'MTG002',
      title: '用户需求调研座谈会',
      description: '与终端用户深入交流，了解实际使用需求和痛点',
      type: '用户访谈',
      status: '已结束',
      scheduledDate: '2024-02-10',
      scheduledTime: '09:00-11:00',
      location: '客户现场',
      organizer: '李四',
      participants: [
        { id: 'P004', name: '赵经理', role: '用户代表', organization: '水厂A' },
        { id: 'P005', name: '刘工', role: '运维人员', organization: '水厂A' },
        { id: 'P006', name: '李四', role: '产品经理', organization: '本公司' }
      ],
      agenda: [
        { id: 'A004', title: '现有系统使用情况', duration: 40, speaker: '赵经理' },
        { id: 'A005', title: '存在问题和建议', duration: 60, speaker: '刘工' },
        { id: 'A006', title: '新功能需求讨论', duration: 20, speaker: '全体' }
      ],
      materials: ['用户手册.pdf', '问题清单.docx'],
      notes: '用户反馈系统响应速度需要提升，界面操作复杂度有待优化...',
      outcomes: [
        '确定界面优化方向',
        '收集3个关键功能需求',
        '制定用户培训计划'
      ],
      createdAt: '2024-01-25'
    },
    {
      id: 'MTG003',
      title: '技术方案评审会',
      description: '对污水处理工艺优化方案进行技术评审',
      type: '技术交流',
      status: '进行中',
      scheduledDate: '2024-02-12',
      scheduledTime: '10:00-12:00',
      location: '技术中心',
      organizer: '王五',
      participants: [
        { id: 'P007', name: '孙总工', role: '技术总监', organization: '本公司' },
        { id: 'P008', name: '马博士', role: '工艺专家', organization: '研究院' },
        { id: 'P009', name: '王五', role: '项目经理', organization: '本公司' }
      ],
      agenda: [
        { id: 'A007', title: '工艺方案介绍', duration: 45, speaker: '王五' },
        { id: 'A008', title: '技术风险评估', duration: 45, speaker: '马博士' },
        { id: 'A009', title: '实施方案讨论', duration: 30, speaker: '全体' }
      ],
      materials: ['技术方案.pptx', '工艺流程图.pdf'],
      notes: '正在进行中...',
      outcomes: [],
      createdAt: '2024-02-01'
    }
  ]
  
  filteredMeetings.value = [...meetings.value]
}

/**
 * 获取状态颜色
 */
function getStatusColor(status) {
  const colors = {
    '筹备中': 'orange',
    '进行中': 'blue', 
    '已结束': 'green',
    '已取消': 'red'
  }
  return colors[status] || 'default'
}

/**
 * 获取本月会议数量
 */
function getMonthlyMeetings() {
  const currentMonth = dayjs().format('YYYY-MM')
  return meetings.value.filter(meeting => 
    meeting.scheduledDate.startsWith(currentMonth) && meeting.status === '已结束'
  ).length
}

/**
 * 获取待举办会议数量
 */
function getPendingMeetings() {
  return meetings.value.filter(meeting => 
    meeting.status === '筹备中' || meeting.status === '进行中'
  ).length
}

/**
 * 获取参与总人数
 */
function getTotalParticipants() {
  return meetings.value.reduce((total, meeting) => total + meeting.participants.length, 0)
}

/**
 * 根据日期获取会议
 */
function getMeetingsByDate(date) {
  const dateStr = date.format('YYYY-MM-DD')
  return meetings.value.filter(meeting => meeting.scheduledDate === dateStr)
}

/**
 * 筛选处理
 */
function handleFilter() {
  let filtered = [...meetings.value]
  
  if (filterStatus.value) {
    filtered = filtered.filter(meeting => meeting.status === filterStatus.value)
  }
  
  if (filterType.value) {
    filtered = filtered.filter(meeting => meeting.type === filterType.value)
  }
  
  if (filterDateRange.value && filterDateRange.value.length === 2) {
    const [startDate, endDate] = filterDateRange.value
    filtered = filtered.filter(meeting => {
      const meetingDate = dayjs(meeting.scheduledDate)
      return meetingDate.isAfter(startDate) && meetingDate.isBefore(endDate)
    })
  }
  
  if (searchKeyword.value) {
    const keyword = searchKeyword.value.toLowerCase()
    filtered = filtered.filter(meeting => 
      meeting.title.toLowerCase().includes(keyword) ||
      meeting.description.toLowerCase().includes(keyword) ||
      meeting.participants.some(p => p.name.toLowerCase().includes(keyword))
    )
  }
  
  filteredMeetings.value = filtered
}

/**
 * 视图切换
 */
function handleViewChange() {
  // 视图切换逻辑
}

/**
 * 日历选择
 */
function onCalendarSelect(date) {
  selectedDate.value = date
}

/**
 * 保存会议
 */
function saveMeeting(meetingData) {
  if (currentMeeting.value) {
    // 编辑现有会议
    const index = meetings.value.findIndex(meeting => meeting.id === currentMeeting.value.id)
    meetings.value[index] = { ...meetingData }
    message.success('座谈会信息更新成功')
  } else {
    // 新增会议
    const newMeeting = {
      ...meetingData,
      id: `MTG${String(meetings.value.length + 1).padStart(3, '0')}`,
      status: '筹备中',
      createdAt: new Date().toISOString().split('T')[0]
    }
    meetings.value.unshift(newMeeting)
    message.success('座谈会创建成功')
  }
  
  handleFilter()
  showAddMeetingModal.value = false
  currentMeeting.value = null
}

/**
 * 编辑会议
 */
function editMeeting(meeting) {
  currentMeeting.value = { ...meeting }
  showAddMeetingModal.value = true
}

/**
 * 查看会议详情
 */
function viewMeetingDetail(meeting) {
  selectedMeeting.value = meeting
  showDetailDrawer.value = true
}

/**
 * 开始会议
 */
function startMeeting(meeting) {
  const index = meetings.value.findIndex(m => m.id === meeting.id)
  meetings.value[index].status = '进行中'
  handleFilter()
  message.success('会议已开始')
}

/**
 * 结束会议
 */
function endMeeting(meeting) {
  const index = meetings.value.findIndex(m => m.id === meeting.id)
  meetings.value[index].status = '已结束'
  handleFilter()
  message.success('会议已结束')
}

/**
 * 导出会议
 */
function exportMeetings() {
  message.success('会议纪要导出功能开发中...')
}

/**
 * 需求选择
 */
function handleRequirementChange(value) {
  console.log('当前选择需求:', value)
  // 根据需求ID加载相关数据
}

/**
 * 生命周期钩子
 */
onMounted(() => {
  initMockData()
})
</script>

<style scoped>
.meeting-management {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}

.header-content {
  flex: 1;
}

.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 24px;
  color: #234fa2;
  margin: 0 0 8px 0;
}

.page-desc {
  color: #64748b;
  margin: 0;
  font-size: 14px;
}

.header-actions {
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}

.stats-section {
  margin-bottom: 24px;
}

.filter-section {
  background: #fff;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
  margin-bottom: 24px;
}

.view-controls {
  text-align: right;
}

.meetings-list {
  margin-bottom: 24px;
}

.meeting-card {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
  margin-bottom: 16px;
  padding: 24px;
  transition: all 0.3s ease;
}

.meeting-card:hover {
  box-shadow: 0 4px 20px rgba(35,79,162,0.12);
}

.meeting-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 16px;
}

.meeting-info {
  flex: 1;
}

.meeting-title {
  font-size: 18px;
  color: #234fa2;
  margin: 0 0 8px 0;
}

.meeting-meta {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-wrap: wrap;
}

.meeting-time,
.meeting-location {
  display: flex;
  align-items: center;
  gap: 4px;
  color: #64748b;
  font-size: 14px;
}

.meeting-content {
  border-top: 1px solid #f0f0f0;
  padding-top: 16px;
}

.meeting-description {
  margin-bottom: 16px;
}

.meeting-description p {
  color: #64748b;
  margin: 0;
  line-height: 1.6;
}

.meeting-participants {
  display: flex;
  gap: 32px;
}

.participants-section,
.agenda-section {
  flex: 1;
}

.participants-section h4,
.agenda-section h4 {
  font-size: 14px;
  color: #234fa2;
  margin: 0 0 8px 0;
}

.participants-list {
  display: flex;
  align-items: center;
  gap: 8px;
}

.more-participants,
.more-agenda {
  color: #64748b;
  font-size: 12px;
}

.agenda-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.calendar-view {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
  padding: 24px;
}

.calendar-meetings {
  padding: 2px;
}

.calendar-meeting-item {
  font-size: 12px;
  padding: 2px 4px;
  border-radius: 4px;
  margin-bottom: 2px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.calendar-meeting-item:hover {
  transform: scale(1.05);
}

.calendar-meeting-item.status-筹备中 {
  background: #fff7e6;
  border-left: 3px solid #faad14;
}

.calendar-meeting-item.status-进行中 {
  background: #e6f7ff;
  border-left: 3px solid #1890ff;
}

.calendar-meeting-item.status-已结束 {
  background: #f6ffed;
  border-left: 3px solid #52c41a;
}

.meeting-time {
  font-weight: bold;
  color: #234fa2;
}

.meeting-title {
  color: #64748b;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.empty-state {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
  padding: 60px 24px;
  text-align: center;
}

/**
 * 响应式设计
 */
@media (max-width: 768px) {
  .meeting-management {
    padding: 16px;
  }
  
  .page-header {
    flex-direction: column;
    gap: 16px;
  }
  
  .header-actions {
    align-self: stretch;
  }
  
  .meeting-header {
    flex-direction: column;
    gap: 16px;
  }
  
  .meeting-meta {
    flex-direction: column;
    align-items: flex-start;
    gap: 8px;
  }
  
  .meeting-participants {
    flex-direction: column;
    gap: 16px;
  }
  
  .stats-section .ant-col {
    margin-bottom: 16px;
  }
}
</style> 