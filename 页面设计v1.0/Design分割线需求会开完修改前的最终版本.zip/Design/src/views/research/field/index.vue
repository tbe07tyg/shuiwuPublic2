<template>
  <div class="field-research">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">
          <EnvironmentOutlined />
          实地调研管理
        </h1>
        <p class="page-desc">基于需求进行现场调研，收集第一手资料</p>
      </div>
      <div class="header-actions">
        <a-button type="primary" @click="showCreatePlan = true">
          <PlusOutlined />
          制定调研计划
        </a-button>
        <a-button @click="exportResearchData">
          <DownloadOutlined />
          导出调研数据
        </a-button>
        <a-button type="dashed" @click="testModal">
          测试弹窗
        </a-button>
      </div>
    </div>

    <!-- 关联需求信息 -->
    <div class="related-requirement" v-if="relatedRequirement">
      <div class="requirement-info">
        <h3>
          <LinkOutlined />
          关联需求
        </h3>
        <div class="requirement-content">
          <div class="requirement-title">{{ relatedRequirement.title }}</div>
          <div class="requirement-meta">
            <a-tag :color="getPriorityColor(relatedRequirement.priority)">
              {{ relatedRequirement.priority }}优先级
            </a-tag>
            <a-tag>{{ relatedRequirement.category }}</a-tag>
            <span class="proposer">提出人：{{ relatedRequirement.proposer }}</span>
          </div>
        </div>
      </div>
      <a-button type="link" @click="viewRequirementDetail">查看需求详情</a-button>
    </div>

    <!-- 调研计划概览 -->
    <div class="research-overview">
      <a-row :gutter="16">
        <a-col :span="6">
          <a-card class="stat-card">
            <a-statistic 
              title="调研计划" 
              :value="researchPlans.length" 
              suffix="个"
              :value-style="{ color: '#234fa2' }"
            />
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card class="stat-card">
            <a-statistic 
              title="进行中" 
              :value="getStatusCount('进行中')" 
              suffix="个"
              :value-style="{ color: '#1890ff' }"
            />
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card class="stat-card">
            <a-statistic 
              title="已完成" 
              :value="getStatusCount('已完成')" 
              suffix="个"
              :value-style="{ color: '#52c41a' }"
            />
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card class="stat-card">
            <a-statistic 
              title="调研记录" 
              :value="getTotalRecords()" 
              suffix="条"
              :value-style="{ color: '#fa8c16' }"
            />
          </a-card>
        </a-col>
      </a-row>
    </div>

    <!-- 调研计划列表 -->
    <div class="research-plans">
      <div class="section-header">
        <h2>调研计划</h2>
        <a-space>
          <a-select 
            v-model:value="filterStatus" 
            placeholder="筛选状态" 
            style="width: 120px"
            @change="handleFilter"
          >
            <a-select-option value="">全部状态</a-select-option>
            <a-select-option value="计划中">计划中</a-select-option>
            <a-select-option value="进行中">进行中</a-select-option>
            <a-select-option value="已完成">已完成</a-select-option>
            <a-select-option value="已暂停">已暂停</a-select-option>
          </a-select>
          <a-input-search
            v-model:value="searchKeyword"
            placeholder="搜索调研计划"
            style="width: 200px"
            @search="handleFilter"
          />
        </a-space>
      </div>

      <a-row :gutter="16">
        <a-col 
          v-for="plan in filteredPlans" 
          :key="plan.id" 
          :span="8"
        >
          <ResearchPlanCard
            :plan="plan"
            :requirements="requirements"
            @edit="editPlan"
            @delete="deletePlan"
            @start="startResearch"
            @view-records="viewResearchRecords"
            @add-record="addResearchRecord"
          />
        </a-col>
      </a-row>
    </div>

    <!-- 调研记录列表 -->
    <div class="research-records" v-if="currentPlan">
      <div class="section-header">
        <h2>调研记录 - {{ currentPlan.title }}</h2>
        <a-button type="primary" @click="showRecordModal = true">
          <PlusOutlined />
          添加记录
        </a-button>
      </div>

      <a-timeline>
        <a-timeline-item 
          v-for="record in currentPlan.records" 
          :key="record.id"
          :color="getRecordStatusColor(record.status)"
        >
          <ResearchRecordItem
            :record="record"
            @edit="editRecord"
            @delete="deleteRecord"
            @view-photos="viewPhotos"
          />
        </a-timeline-item>
      </a-timeline>
    </div>

    <!-- 制定调研计划弹窗 -->
    <ResearchPlanModal
      v-model:visible="showCreatePlan"
      :requirements="requirements"
      :requirement="relatedRequirement"
      :plan="currentEditPlan"
      @save="savePlan"
    />

    <!-- 添加调研记录弹窗 -->
    <ResearchRecordModal
      v-model:visible="showRecordModal"
      :plan="currentPlan"
      :record="currentEditRecord"
      @save="saveRecord"
    />

    <!-- 图片查看器 -->
    <a-modal
      v-model:open="showPhotoViewer"
      title="调研照片"
      :footer="null"
      width="800px"
      centered
    >
      <div class="photo-gallery">
        <img 
          v-for="(photo, index) in currentPhotos" 
          :key="index"
          :src="photo.url" 
          :alt="photo.description"
          class="gallery-image"
        />
      </div>
    </a-modal>

    <!-- 需求详情抽屉 -->
    <a-drawer
      v-model:open="showRequirementDrawer"
      title="需求详情"
      width="600"
      placement="right"
    >
      <RequirementDetail
        v-if="relatedRequirement"
        :requirement="relatedRequirement"
        @edit="editRequirement"
      />
    </a-drawer>

    <!-- 测试弹窗 -->
    <a-modal
      v-model:open="showTestModal"
      title="测试弹窗"
      :footer="null"
      width="600px"
      centered
    >
      <p>这是一个简单的测试弹窗。</p>
    </a-modal>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { message } from 'ant-design-vue'
import {
  EnvironmentOutlined,
  PlusOutlined,
  DownloadOutlined,
  LinkOutlined
} from '@ant-design/icons-vue'
import ResearchPlanCard from '@/components/research/ResearchPlanCard.vue'
import ResearchPlanModal from '@/components/research/ResearchPlanModal.vue'
import ResearchRecordModal from '@/components/research/ResearchRecordModal.vue'
import ResearchRecordItem from '@/components/research/ResearchRecordItem.vue'
import RequirementDetail from '@/components/research/RequirementDetail.vue'

const route = useRoute()
const router = useRouter()

/**
 * 响应式数据定义
 */
const relatedRequirement = ref(null)
const researchPlans = ref([])
const filteredPlans = ref([])
const currentPlan = ref(null)
const currentEditPlan = ref(null)
const currentEditRecord = ref(null)
const currentPhotos = ref([])
const requirements = ref([
  { id: 'R001', name: '需求A' },
  { id: 'R002', name: '需求B' }
])
const selectedRequirement = ref()

/**
 * 弹窗控制
 */
const showCreatePlan = ref(false)
const showRecordModal = ref(false)
const showPhotoViewer = ref(false)
const showRequirementDrawer = ref(false)
const showTestModal = ref(false)

/**
 * 筛选条件
 */
const filterStatus = ref('')
const searchKeyword = ref('')

/**
 * 初始化模拟数据
 */
function initMockData() {
  // 模拟关联需求数据（通常从需求池页面传递）
  if (route.query.requirementId) {
    relatedRequirement.value = {
      id: route.query.requirementId,
      title: '智能水质监测系统升级',
      description: '对现有水质监测系统进行智能化升级，增加AI预警功能和大数据分析能力',
      category: '技术创新',
      priority: '高',
      status: '进行中',
      proposer: '张三',
      proposerDept: '技术部'
    }
  }

  // 模拟调研计划数据
  researchPlans.value = [
    {
      id: 'RP001',
      title: '水质监测现状调研',
      description: '调研目前水质监测设备的运行状况和存在问题',
      requirementId: 'REQ001',
      status: '已完成',
      planDate: '2024-01-20',
      expectedDuration: 3,
      actualDuration: 2,
      locations: ['水厂A', '水厂B', '水厂C'],
      participants: ['张三', '李四', '王五'],
      leader: '张三',
      objectives: [
        '了解现有设备型号和技术参数',
        '分析设备运行数据和故障记录',
        '收集用户使用反馈和改进建议'
      ],
      records: [
        {
          id: 'RR001',
          date: '2024-01-20',
          location: '水厂A',
          recorder: '张三',
          status: '已完成',
          content: '设备运行正常，但精度有待提升',
          photos: [
            { url: '/api/photos/1.jpg', description: '监测设备外观' },
            { url: '/api/photos/2.jpg', description: '控制面板' }
          ],
          findings: [
            '设备已使用5年，部分传感器老化',
            '数据传输存在偶发性延迟',
            '用户界面不够直观'
          ]
        }
      ]
    },
    {
      id: 'RP002',
      title: '用户需求深度调研',
      description: '深入了解一线操作人员的使用需求和痛点',
      requirementId: 'REQ001',
      status: '进行中',
      planDate: '2024-01-25',
      expectedDuration: 5,
      actualDuration: null,
      locations: ['水厂D', '水厂E'],
      participants: ['李四', '王五'],
      leader: '李四',
      objectives: [
        '收集一线操作人员反馈',
        '了解日常操作流程',
        '识别自动化改进空间'
      ],
      records: []
    }
  ]

  filteredPlans.value = [...researchPlans.value]
}

/**
 * 获取状态数量统计
 */
function getStatusCount(status) {
  return researchPlans.value.filter(plan => plan.status === status).length
}

/**
 * 获取总记录数
 */
function getTotalRecords() {
  return researchPlans.value.reduce((total, plan) => total + (plan.records?.length || 0), 0)
}

/**
 * 获取优先级颜色
 */
function getPriorityColor(priority) {
  const colors = { '高': 'red', '中': 'orange', '低': 'blue' }
  return colors[priority] || 'default'
}

/**
 * 获取记录状态颜色
 */
function getRecordStatusColor(status) {
  const colors = {
    '计划中': 'blue',
    '进行中': 'processing',
    '已完成': 'green',
    '已暂停': 'orange'
  }
  return colors[status] || 'blue'
}

/**
 * 筛选处理
 */
function handleFilter() {
  let filtered = [...researchPlans.value]
  
  if (filterStatus.value) {
    filtered = filtered.filter(plan => plan.status === filterStatus.value)
  }
  
  if (searchKeyword.value) {
    const keyword = searchKeyword.value.toLowerCase()
    filtered = filtered.filter(plan => 
      plan.title.toLowerCase().includes(keyword) ||
      plan.description.toLowerCase().includes(keyword)
    )
  }
  
  filteredPlans.value = filtered
}

/**
 * 保存调研计划
 */
function savePlan(planData) {
  if (currentEditPlan.value) {
    // 编辑现有计划
    const index = researchPlans.value.findIndex(plan => plan.id === currentEditPlan.value.id)
    researchPlans.value[index] = { ...planData }
    message.success('调研计划更新成功')
  } else {
    // 新增计划
    const newPlan = {
      ...planData,
      id: `RP${String(researchPlans.value.length + 1).padStart(3, '0')}`,
      status: '计划中',
      records: []
    }
    researchPlans.value.unshift(newPlan)
    message.success('调研计划创建成功')
  }
  handleFilter()
  showCreatePlan.value = false
  currentEditPlan.value = null
}

/**
 * 编辑调研计划
 */
function editPlan(plan) {
  console.log('编辑计划:', plan)
  currentEditPlan.value = { ...plan }
  showCreatePlan.value = true
  console.log('弹窗状态:', showCreatePlan.value)
}

/**
 * 删除调研计划
 */
function deletePlan(plan) {
  console.log('删除计划:', plan)
  const index = researchPlans.value.findIndex(p => p.id === plan.id)
  researchPlans.value.splice(index, 1)
  handleFilter()
  message.success('调研计划删除成功')
}

/**
 * 开始调研
 */
function startResearch(plan) {
  console.log('开始调研:', plan)
  const planIndex = researchPlans.value.findIndex(p => p.id === plan.id)
  researchPlans.value[planIndex].status = '进行中'
  handleFilter()
  message.success('调研已开始')
}

/**
 * 查看调研记录
 */
function viewResearchRecords(plan) {
  console.log('查看记录:', plan)
  currentPlan.value = plan
}

/**
 * 添加调研记录
 */
function addResearchRecord(plan) {
  console.log('添加记录:', plan)
  currentPlan.value = plan
  currentEditRecord.value = null
  showRecordModal.value = true
  console.log('记录弹窗状态:', showRecordModal.value)
}

/**
 * 保存调研记录
 */
function saveRecord(recordData) {
  if (currentEditRecord.value) {
    // 编辑现有记录
    const recordIndex = currentPlan.value.records.findIndex(r => r.id === currentEditRecord.value.id)
    currentPlan.value.records[recordIndex] = { ...recordData }
    message.success('调研记录更新成功')
  } else {
    // 新增记录
    const newRecord = {
      ...recordData,
      id: `RR${String(Date.now()).slice(-3)}`,
      status: '已完成'
    }
    currentPlan.value.records.push(newRecord)
    message.success('调研记录添加成功')
  }
  
  showRecordModal.value = false
  currentEditRecord.value = null
}

/**
 * 编辑调研记录
 */
function editRecord(record) {
  currentEditRecord.value = { ...record }
  showRecordModal.value = true
}

/**
 * 删除调研记录
 */
function deleteRecord(record) {
  const index = currentPlan.value.records.findIndex(r => r.id === record.id)
  currentPlan.value.records.splice(index, 1)
  message.success('调研记录删除成功')
}

/**
 * 查看照片
 */
function viewPhotos(photos) {
  currentPhotos.value = photos
  showPhotoViewer.value = true
}

/**
 * 查看需求详情
 */
function viewRequirementDetail() {
  showRequirementDrawer.value = true
}

/**
 * 编辑需求
 */
function editRequirement(requirement) {
  router.push({
    path: '/research/requirements',
    query: { edit: requirement.id }
  })
}

/**
 * 导出调研数据
 */
function exportResearchData() {
  message.success('调研数据导出功能开发中...')
}

/**
 * 测试弹窗
 */
function testModal() {
  console.log('测试弹窗被点击')
  showTestModal.value = true
  console.log('测试弹窗状态:', showTestModal.value)
}

/**
 * 需求选择变化处理
 */
function handleRequirementChange(value) {
  console.log('当前选择需求:', value)
  // 根据需求ID加载相关数据
}

/**
 * 生命周期钩子
 */
onMounted(() => {
  initMockData()
})
</script>

<style scoped>
.field-research {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}

.header-content {
  flex: 1;
}

.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 24px;
  color: #234fa2;
  margin: 0 0 8px 0;
}

.page-desc {
  color: #64748b;
  margin: 0;
  font-size: 14px;
}

.header-actions {
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}

.related-requirement {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
  padding: 20px;
  margin-bottom: 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-left: 4px solid #1890ff;
}

.requirement-info h3 {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #234fa2;
  margin: 0 0 12px 0;
  font-size: 16px;
}

.requirement-title {
  font-size: 16px;
  font-weight: 600;
  color: #234fa2;
  margin-bottom: 8px;
}

.requirement-meta {
  display: flex;
  align-items: center;
  gap: 12px;
}

.proposer {
  color: #64748b;
  font-size: 14px;
}

.research-overview {
  margin-bottom: 32px;
}

.stat-card {
  text-align: center;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}

.research-plans {
  margin-bottom: 32px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.section-header h2 {
  color: #234fa2;
  margin: 0;
  font-size: 20px;
}

.research-records {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
  padding: 24px;
}

.photo-gallery {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  max-height: 400px;
  overflow-y: auto;
}

.gallery-image {
  width: 100%;
  height: 150px;
  object-fit: cover;
  border-radius: 8px;
  border: 1px solid #f0f0f0;
}

/**
 * 响应式设计
 */
@media (max-width: 768px) {
  .field-research {
    padding: 16px;
  }
  
  .page-header {
    flex-direction: column;
    gap: 16px;
  }
  
  .header-actions {
    align-self: stretch;
  }
  
  .related-requirement {
    flex-direction: column;
    gap: 16px;
    align-items: stretch;
  }
  
  .section-header {
    flex-direction: column;
    gap: 12px;
    align-items: stretch;
  }
  
  .photo-gallery {
    grid-template-columns: 1fr;
  }
}
</style> 