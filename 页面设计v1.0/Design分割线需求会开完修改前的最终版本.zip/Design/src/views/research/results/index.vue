<template>
  <div class="results-page">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">
          <FileDoneOutlined />
          调研成果
        </h1>
        <p class="page-desc">集中管理和展示调研阶段的各类成果文档、报告与结论</p>
      </div>
      <div class="header-actions">
        <a-select v-model:value="selectedRequirement" placeholder="选择需求" style="width: 220px; margin-right: 12px;" @change="handleRequirementChange">
          <a-select-option v-for="req in requirements" :key="req.id" :value="req.id">{{ req.name }}</a-select-option>
        </a-select>
        <a-button type="primary" @click="showAddModal = true">
          <PlusOutlined /> 新增成果
        </a-button>
        <a-button @click="exportResults">
          <DownloadOutlined /> 导出成果
        </a-button>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-section">
      <a-row :gutter="16">
        <a-col :span="6">
          <a-card>
            <a-statistic title="成果总数" :value="results.length" :value-style="{ color: '#234fa2' }">
              <template #prefix><FileDoneOutlined /></template>
            </a-statistic>
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card>
            <a-statistic title="本月新增" :value="getMonthlyResults()" :value-style="{ color: '#52c41a' }">
              <template #prefix><CalendarOutlined /></template>
            </a-statistic>
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card>
            <a-statistic title="报告类成果" :value="getTypeCount('报告')" :value-style="{ color: '#1890ff' }">
              <template #prefix><FileTextOutlined /></template>
            </a-statistic>
          </a-card>
        </a-col>
        <a-col :span="6">
          <a-card>
            <a-statistic title="结论类成果" :value="getTypeCount('结论')" :value-style="{ color: '#faad14' }">
              <template #prefix><CheckCircleOutlined /></template>
            </a-statistic>
          </a-card>
        </a-col>
      </a-row>
    </div>

    <!-- 筛选区域 -->
    <div class="filter-section">
      <a-row :gutter="16">
        <a-col :span="20">
          <a-space size="middle">
            <a-select v-model:value="filterType" placeholder="成果类型" style="width: 120px" @change="handleFilter">
              <a-select-option value="">全部类型</a-select-option>
              <a-select-option value="报告">报告</a-select-option>
              <a-select-option value="结论">结论</a-select-option>
              <a-select-option value="图片">图片</a-select-option>
              <a-select-option value="其他">其他</a-select-option>
            </a-select>
            <a-range-picker v-model:value="filterDateRange" placeholder="选择时间范围" @change="handleFilter" />
            <a-input-search v-model:value="searchKeyword" placeholder="搜索标题/描述/标签" style="width: 250px" @search="handleFilter" />
          </a-space>
        </a-col>
      </a-row>
    </div>

    <!-- 成果列表 -->
    <div class="results-list">
      <a-row :gutter="16">
        <a-col :span="8" v-for="item in filteredResults" :key="item.id">
          <a-card class="result-card" @click="viewDetail(item)">
            <div class="result-title">{{ item.title }}</div>
            <div class="result-meta">
              <a-tag :color="getTypeColor(item.type)">{{ item.type }}</a-tag>
              <span class="result-date"><CalendarOutlined /> {{ item.date }}</span>
              <span v-if="item.researchPlanId" class="research-plan">
                <EnvironmentOutlined /> 调研计划：{{ getResearchPlanTitle(item.researchPlanId) }}
              </span>
              <span v-if="item.meetingId" class="meeting">
                <TeamOutlined /> 座谈会：{{ getMeetingTitle(item.meetingId) }}
              </span>
            </div>
            <div class="result-desc">{{ item.description }}</div>
            <div class="result-tags">
              <a-tag v-for="tag in item.tags" :key="tag">{{ tag }}</a-tag>
            </div>
          </a-card>
        </a-col>
      </a-row>
      <div v-if="filteredResults.length === 0" class="empty-state">
        <a-empty description="暂无调研成果">
          <a-button type="primary" @click="showAddModal = true">新增成果</a-button>
        </a-empty>
      </div>
    </div>

    <!-- 新增/编辑成果弹窗 -->
    <a-modal v-model:open="showAddModal" title="新增成果" @ok="handleAddResult">
      <a-form :model="newResult" layout="vertical">
        <a-form-item label="标题" required>
          <a-input v-model:value="newResult.title" />
        </a-form-item>
        <a-form-item label="类型" required>
          <a-select v-model:value="newResult.type">
            <a-select-option value="报告">报告</a-select-option>
            <a-select-option value="结论">结论</a-select-option>
            <a-select-option value="图片">图片</a-select-option>
            <a-select-option value="其他">其他</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="描述">
          <a-textarea v-model:value="newResult.description" :rows="3" />
        </a-form-item>
        <a-form-item label="标签">
          <a-input v-model:value="newResult.tags" placeholder="多个标签用逗号分隔" />
        </a-form-item>
        <a-form-item label="绑定调研计划" name="researchPlanId">
          <a-select v-model:value="newResult.researchPlanId" placeholder="请选择调研计划">
            <a-select-option v-for="plan in researchPlans" :key="plan.id" :value="plan.id">{{ plan.title }}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="绑定座谈会" name="meetingId">
          <a-select v-model:value="newResult.meetingId" placeholder="请选择座谈会">
            <a-select-option v-for="meeting in meetings" :key="meeting.id" :value="meeting.id">{{ meeting.title }}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="附件">
          <a-upload
            v-model:file-list="newResult.attachments"
            :before-upload="beforeUpload"
            multiple
          >
            <a-button>
              <UploadOutlined /> 上传附件
            </a-button>
          </a-upload>
        </a-form-item>
      </a-form>
    </a-modal>

    <!-- 成果详情抽屉 -->
    <a-drawer v-model:open="showDetailDrawer" title="成果详情" width="600">
      <div v-if="selectedResult">
        <h2>{{ selectedResult.title }}</h2>
        <div class="result-meta">
          <a-tag :color="getTypeColor(selectedResult.type)">{{ selectedResult.type }}</a-tag>
          <span class="result-date"><CalendarOutlined /> {{ selectedResult.date }}</span>
          <span v-if="selectedResult.researchPlanId" class="research-plan">
            <EnvironmentOutlined /> 调研计划：{{ getResearchPlanTitle(selectedResult.researchPlanId) }}
          </span>
          <span v-if="selectedResult.meetingId" class="meeting">
            <TeamOutlined /> 座谈会：{{ getMeetingTitle(selectedResult.meetingId) }}
          </span>
        </div>
        <div class="result-desc">{{ selectedResult.description }}</div>
        <div class="result-tags">
          <a-tag v-for="tag in selectedResult.tags" :key="tag">{{ tag }}</a-tag>
        </div>
        <div v-if="selectedResult.attachments && selectedResult.attachments.length > 0" class="result-attachments">
          <h3>附件</h3>
          <a-list :data-source="selectedResult.attachments" :bordered="false">
            <template #renderItem="{ item }">
              <a-list-item>
                <a :href="item.url" target="_blank" download>
                  <FileOutlined /> {{ item.name }}
                </a>
              </a-list-item>
            </template>
          </a-list>
        </div>
      </div>
    </a-drawer>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { message } from 'ant-design-vue'
import dayjs from 'dayjs'
import {
  FileDoneOutlined,
  PlusOutlined,
  DownloadOutlined,
  CalendarOutlined,
  FileTextOutlined,
  CheckCircleOutlined,
  EnvironmentOutlined,
  TeamOutlined,
  UploadOutlined,
  FileOutlined
} from '@ant-design/icons-vue'

/**
 * @typedef {Object} ResultItem
 * @property {string} id
 * @property {string} title
 * @property {string} type
 * @property {string} date
 * @property {string} description
 * @property {string[]} tags
 */

const results = ref([])
const filteredResults = ref([])
const showAddModal = ref(false)
const showDetailDrawer = ref(false)
const selectedResult = ref(null)
const filterType = ref('')
const filterDateRange = ref([])
const searchKeyword = ref('')
const newResult = ref({
  title: '',
  type: '',
  description: '',
  tags: '',
  researchPlanId: '',
  meetingId: '',
  attachments: []
})
const requirements = ref([
  { id: 'R001', name: '需求A' },
  { id: 'R002', name: '需求B' }
])
const selectedRequirement = ref()
const researchPlans = ref([])
const meetings = ref([])

/**
 * 初始化模拟数据
 */
function initMockData() {
  researchPlans.value = [
    { id: 'RP001', title: '水质监测现状调研' },
    { id: 'RP002', title: '用户需求深度调研' }
  ]
  meetings.value = [
    { id: 'MTG001', title: '智能水质监测系统专家咨询会' },
    { id: 'MTG002', title: '用户需求调研座谈会' }
  ]
  results.value = [
    {
      id: 'R001',
      title: '用户需求调研报告',
      type: '报告',
      date: '2024-02-10',
      description: '总结用户访谈和需求收集的主要结论',
      tags: ['用户', '需求', '报告'],
      attachments: [
        { name: '调研报告.pdf', url: 'https://example.com/调研报告.pdf' }
      ]
    },
    {
      id: 'R002',
      title: '水质监测技术结论',
      type: '结论',
      date: '2024-02-12',
      description: '对比多种水质监测技术后的最终结论',
      tags: ['技术', '结论'],
      attachments: [
        { name: '技术结论.docx', url: 'https://example.com/技术结论.docx' }
      ]
    },
    {
      id: 'R003',
      title: '调研现场照片',
      type: '图片',
      date: '2024-02-15',
      description: '实地调研过程中的现场照片',
      tags: ['图片', '现场'],
      attachments: [
        { name: '现场照片1.jpg', url: 'https://example.com/现场照片1.jpg' },
        { name: '现场照片2.jpg', url: 'https://example.com/现场照片2.jpg' }
      ]
    }
  ]
  filteredResults.value = [...results.value]
}

/**
 * 统计卡片相关
 */
function getMonthlyResults() {
  const currentMonth = dayjs().format('YYYY-MM')
  return results.value.filter(r => r.date.startsWith(currentMonth)).length
}
function getTypeCount(type) {
  return results.value.filter(r => r.type === type).length
}
function getTypeColor(type) {
  const map = { '报告': 'blue', '结论': 'green', '图片': 'orange', '其他': 'default' }
  return map[type] || 'default'
}

/**
 * 筛选处理
 */
function handleFilter() {
  let filtered = [...results.value]
  if (filterType.value) {
    filtered = filtered.filter(r => r.type === filterType.value)
  }
  if (filterDateRange.value && filterDateRange.value.length === 2) {
    const [start, end] = filterDateRange.value
    filtered = filtered.filter(r => {
      const d = dayjs(r.date)
      return d.isAfter(start) && d.isBefore(end)
    })
  }
  if (searchKeyword.value) {
    const kw = searchKeyword.value.toLowerCase()
    filtered = filtered.filter(r =>
      r.title.toLowerCase().includes(kw) ||
      r.description.toLowerCase().includes(kw) ||
      r.tags.some(tag => tag.toLowerCase().includes(kw))
    )
  }
  filteredResults.value = filtered
}

/**
 * 新增成果
 */
function handleAddResult() {
  if (!newResult.value.title || !newResult.value.type) {
    message.error('请填写必填项')
    return
  }
  results.value.unshift({
    id: `R${String(results.value.length + 1).padStart(3, '0')}`,
    title: newResult.value.title,
    type: newResult.value.type,
    date: dayjs().format('YYYY-MM-DD'),
    description: newResult.value.description,
    tags: newResult.value.tags ? newResult.value.tags.split(',').map(t => t.trim()) : [],
    researchPlanId: newResult.value.researchPlanId,
    meetingId: newResult.value.meetingId,
    attachments: newResult.value.attachments.map(file => ({
      name: file.name,
      url: URL.createObjectURL(file)
    }))
  })
  handleFilter()
  showAddModal.value = false
  newResult.value = { title: '', type: '', description: '', tags: '', researchPlanId: '', meetingId: '', attachments: [] }
  message.success('成果添加成功')
}

/**
 * 导出成果
 */
function exportResults() {
  message.success('导出功能开发中...')
}

/**
 * 查看详情
 */
function viewDetail(item) {
  selectedResult.value = item
  showDetailDrawer.value = true
}

function handleRequirementChange(value) {
  console.log('当前选择需求:', value)
  // 根据需求ID加载相关数据
}

function beforeUpload(file) {
  const isLt10M = file.size / 1024 / 1024 < 10
  if (!isLt10M) {
    message.error('附件大小不能超过10MB!')
  }
  return isLt10M
}

function getResearchPlanTitle(id) {
  const plan = researchPlans.value.find(p => p.id === id)
  return plan ? plan.title : '未知计划'
}

function getMeetingTitle(id) {
  const meeting = meetings.value.find(m => m.id === id)
  return meeting ? meeting.title : '未知座谈会'
}

onMounted(() => {
  initMockData()
})
</script>

<style scoped>
.results-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}
.header-content {
  flex: 1;
}
.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 24px;
  color: #234fa2;
  margin: 0 0 8px 0;
}
.page-desc {
  color: #64748b;
  margin: 0;
  font-size: 14px;
}
.header-actions {
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}
.stats-section {
  margin-bottom: 24px;
}
.filter-section {
  background: #fff;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
  margin-bottom: 24px;
}
.results-list {
  margin-bottom: 24px;
}
.result-card {
  margin-bottom: 16px;
  cursor: pointer;
  transition: box-shadow 0.2s;
}
.result-card:hover {
  box-shadow: 0 4px 20px rgba(35,79,162,0.12);
}
.result-title {
  font-size: 18px;
  color: #234fa2;
  margin-bottom: 8px;
}
.result-meta {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 8px;
}
.result-date {
  color: #64748b;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 4px;
}
.result-desc {
  color: #64748b;
  margin-bottom: 8px;
  min-height: 32px;
}
.result-tags {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
.empty-state {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
  padding: 60px 24px;
  text-align: center;
}
.result-attachments {
  margin-top: 24px;
}
.result-attachments h3 {
  font-size: 18px;
  color: #234fa2;
  margin-bottom: 16px;
}
.result-attachments a-list {
  margin-bottom: 16px;
}
@media (max-width: 768px) {
  .results-page {
    padding: 16px;
  }
  .page-header {
    flex-direction: column;
    gap: 16px;
  }
  .header-actions {
    align-self: stretch;
  }
  .result-card {
    margin-bottom: 12px;
  }
}
</style> 