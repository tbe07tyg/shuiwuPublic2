<template>
  <div class="inquiry-page">
    <div class="page-header">
      <h1 class="page-title">询价管理</h1>
      <p class="page-desc">支持向供应商发送询价短信或复制链接，收集报价与方案</p>
    </div>
    <a-card class="inquiry-form-section" title="发起询价">
      <a-form layout="inline">
        <a-form-item label="需求选择">
          <a-select v-model:value="selectedRequirements" mode="multiple" placeholder="请选择需求" style="width: 220px">
            <a-select-option v-for="req in requirements" :key="req.id" :value="req.id">{{ req.name }}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="供应商选择">
          <a-select v-model:value="selectedSuppliers" mode="multiple" placeholder="请选择供应商" style="width: 220px">
            <a-select-option v-for="sup in suppliers" :key="sup.id" :value="sup.id">
              {{ sup.name }}<span v-if="sup.external" style="color:#888;font-size:12px;">（外部系统）</span>
            </a-select-option>
          </a-select>
          <a-button style="margin-left:8px;" @click="showImportModal = true">从外部系统导入</a-button>
        </a-form-item>
        <a-form-item>
          <a-button type="primary" @click="sendSms">发送短信</a-button>
        </a-form-item>
        <a-form-item>
          <a-button @click="copyLinks">复制链接</a-button>
        </a-form-item>
      </a-form>
    </a-card>
    <a-card class="inquiry-history-section" title="发送历史" style="margin-top: 24px;">
      <template #extra>
        <a-input-search
          v-model:value="searchText"
          placeholder="搜索供应商/需求/方式/状态/时间等"
          style="width: 260px;"
          @search="onSearch"
          allowClear
        />
      </template>
      <a-table :columns="columns" :data-source="filteredHistoryList" rowKey="id" bordered>
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'link'">
            <a-input :value="record.link" readonly style="width: 180px; margin-right:8px;" />
            <a-button size="small" @click="() => copySingleLink(record.link)">复制</a-button>
          </template>
          <template v-if="column.key === 'action'">
            <a-button v-if="record.receipt" size="small" @click="() => showReceipt(record)">查看回执</a-button>
            <a-button size="small" @click="() => remindSms(record)">短信提醒</a-button>
          </template>
          <template v-if="column.key === 'status'">
            <span v-if="record.receipt">已提交回执</span>
            <span v-else>{{ record.status }}</span>
          </template>
        </template>
      </a-table>
    </a-card>
    <a-modal v-model:open="showReceiptModal" title="回执详情" width="420px" :footer="null">
      <div v-if="receiptDetail">
        <div>供应商：{{ receiptDetail.supplier }}</div>
        <div>需求：{{ receiptDetail.requirement }}</div>
        <div>报价金额：{{ receiptDetail.price || '--' }} 元</div>
        <div>回执时间：{{ receiptDetail.receiptTime || '--' }}</div>
        <div style="margin-top:8px;">附件：</div>
        <a-list :data-source="receiptDetail.files || []" bordered>
          <template #renderItem="{ item }">
            <a-list-item>
              <a :href="item.url" target="_blank">{{ item.name }}</a>
            </a-list-item>
          </template>
        </a-list>
      </div>
    </a-modal>
    <a-modal v-model:open="showImportModal" title="导入外部供应商" width="400px" @ok="importExternalSuppliers" @cancel="showImportModal = false">
      <div>
        <p>（模拟）以下供应商数据来源于外部系统：</p>
        <a-checkbox-group v-model:value="externalChecked">
          <a-checkbox v-for="sup in externalSupplierList" :key="sup.id" :value="sup.id">
            {{ sup.name }}（{{ sup.phone }}）
          </a-checkbox>
        </a-checkbox-group>
      </div>
    </a-modal>
  </div>
</template>
<script setup>
import { ref, computed } from 'vue'
import { message } from 'ant-design-vue'
const requirements = ref([
  { id: 'R1', name: '智能水表采购' },
  { id: 'R2', name: '管网监测设备' }
])
const suppliers = ref([
  { id: 'S1', name: '华为', phone: '13800000001' },
  { id: 'S2', name: '中兴', phone: '13800000002' }
])
const selectedRequirements = ref([])
const selectedSuppliers = ref([])
const historyList = ref([
  {
    id: 'S1_R1_sms_1',
    supplier: '华为',
    requirement: '智能水表采购',
    method: '短信',
    link: 'https://inquiry.example.com/S1/R1/token',
    sendTime: '2024-06-01 10:00',
    receiptTime: '2024-06-01 11:20',
    status: '已提交回执',
    receipt: {
      supplier: '华为',
      requirement: '智能水表采购',
      price: '120000',
      receiptTime: '2024-06-01 11:20',
      files: [
        { name: '华为方案.pptx', url: '#' },
        { name: '技术说明.pdf', url: '#' }
      ]
    }
  }
])
const columns = [
  { title: '供应商', dataIndex: 'supplier', key: 'supplier' },
  { title: '需求', dataIndex: 'requirement', key: 'requirement' },
  { title: '发送方式', dataIndex: 'method', key: 'method' },
  { title: '链接', key: 'link' },
  { title: '发送时间', dataIndex: 'sendTime', key: 'sendTime' },
  { title: '回执时间', dataIndex: 'receiptTime', key: 'receiptTime' },
  { title: '状态', key: 'status' },
  { title: '操作', key: 'action' }
]
const showReceiptModal = ref(false)
const receiptDetail = ref(null)
const searchText = ref('')
const showImportModal = ref(false)
const externalChecked = ref([])
const externalSupplierList = ref([
  { id: 'E1', name: '国网电科院', phone: '13800000003', external: true },
  { id: 'E2', name: '中国电建', phone: '13800000004', external: true }
])
const filteredHistoryList = computed(() => {
  if (!searchText.value) return historyList.value
  const s = searchText.value.toLowerCase()
  return historyList.value.filter(item =>
    Object.values(item).some(val =>
      (val && typeof val === 'string' && val.toLowerCase().includes(s)) ||
      (val && typeof val === 'object' && JSON.stringify(val).toLowerCase().includes(s))
    )
  )
})
function sendSms() {
  if (!selectedRequirements.value.length || !selectedSuppliers.value.length) {
    message.warning('请选择需求和供应商')
    return
  }
  selectedSuppliers.value.forEach(sid => {
    selectedRequirements.value.forEach(rid => {
      historyList.value.push({
        id: `${sid}_${rid}_sms_${Date.now()}`,
        supplier: suppliers.value.find(s => s.id === sid)?.name,
        requirement: requirements.value.find(r => r.id === rid)?.name,
        method: '短信',
        link: `https://inquiry.example.com/${sid}/${rid}/token`,
        sendTime: new Date().toLocaleString(),
        receiptTime: '',
        status: '已发送',
        receipt: null
      })
    })
  })
  message.success('短信已发送（模拟）')
}
function copyLinks() {
  if (!selectedRequirements.value.length || !selectedSuppliers.value.length) {
    message.warning('请选择需求和供应商')
    return
  }
  let links = []
  selectedSuppliers.value.forEach(sid => {
    selectedRequirements.value.forEach(rid => {
      const link = `https://inquiry.example.com/${sid}/${rid}/token`
      historyList.value.push({
        id: `${sid}_${rid}_copy_${Date.now()}`,
        supplier: suppliers.value.find(s => s.id === sid)?.name,
        requirement: requirements.value.find(r => r.id === rid)?.name,
        method: '复制',
        link,
        sendTime: new Date().toLocaleString(),
        receiptTime: '',
        status: '已复制',
        receipt: null
      })
      links.push(link)
    })
  })
  navigator.clipboard.writeText(links.join('\n'))
  message.success('所有链接已复制')
}
function copySingleLink(link) {
  navigator.clipboard.writeText(link)
  message.success('链接已复制')
}
function remindSms(record) {
  message.success(`已向${record.supplier}发送短信提醒（模拟）`)
}
function showReceipt(record) {
  // mock: 展示回执详情
  receiptDetail.value = record.receipt || {
    supplier: record.supplier,
    requirement: record.requirement,
    price: '100000',
    receiptTime: record.receiptTime || new Date().toLocaleString(),
    files: [
      { name: '方案.pptx', url: '#' },
      { name: '说明.pdf', url: '#' }
    ]
  }
  showReceiptModal.value = true
}
function onSearch() {}
/**
 * 导入外部系统供应商
 * @description 选中的供应商将合并进suppliers，并用external:true标记
 */
function importExternalSuppliers() {
  const selected = externalSupplierList.value.filter(sup => externalChecked.value.includes(sup.id))
  // 避免重复导入
  selected.forEach(sup => {
    if (!suppliers.value.find(s => s.id === sup.id)) {
      suppliers.value.push({ ...sup })
    }
  })
  showImportModal.value = false
  message.success('已导入外部系统供应商')
}
</script>
<style scoped>
.inquiry-page { padding: 24px; }
.page-header { margin-bottom: 18px; }
.page-title { font-size: 22px; color: #234fa2; }
.page-desc { color: #64748b; margin: 0 0 8px 0; }
.inquiry-form-section { margin-bottom: 24px; }
</style> 