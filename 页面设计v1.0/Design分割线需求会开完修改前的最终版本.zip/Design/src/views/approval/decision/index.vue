<template>
  <div class="approval-decision-page">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">
          <AuditOutlined /> 立项审批
        </h1>
        <p class="page-desc">展示立项审批流程，支持多级审批、意见记录与历史查看</p>
      </div>
      <div class="header-actions">
        <a-tag color="red">对接OA审批流</a-tag>
      </div>
    </div>

    <!-- 审批流程展示区 -->
    <a-card class="flow-section" title="审批流程">
      <a-steps :current="currentStep" direction="horizontal">
        <a-step v-for="(node, idx) in approvalFlow" :key="node.name" :title="node.name" :description="node.status" />
      </a-steps>
      <!-- OA审批流状态同步标记 -->
      <a-tag color="red" style="margin-top:8px;">审批节点与OA系统同步</a-tag>
    </a-card>

    <!-- 审批操作区 -->
    <a-card class="action-section" title="审批操作">
      <a-form :model="approvalForm" layout="vertical">
        <a-form-item label="审批意见" required>
          <a-textarea v-model:value="approvalForm.comment" :rows="3" placeholder="请输入审批意见..." />
        </a-form-item>
        <a-space>
          <a-button type="primary" @click="handleApprove">通过</a-button>
          <a-button danger @click="handleReject">驳回</a-button>
        </a-space>
      </a-form>
      <!-- 审批操作将同步至OA系统 -->
      <a-tag color="red" style="margin-top:8px;">审批操作同步OA系统</a-tag>
    </a-card>

    <!-- 审批历史区 -->
    <a-card class="history-section" title="审批历史">
      <a-timeline>
        <a-timeline-item v-for="item in approvalHistory" :key="item.time">
          <div>
            <b>{{ item.node }}</b> - {{ item.status }}
            <span style="float:right; color:#999">{{ item.time }}</span>
          </div>
          <div>审批人：{{ item.user }}</div>
          <div>意见：{{ item.comment }}</div>
        </a-timeline-item>
      </a-timeline>
    </a-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { AuditOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import { useRoute, useRouter } from 'vue-router'
import { useApprovalStore, nodeOrder } from '@/store/approval'

/**
 * 审批流程节点
 */
const approvalFlow = ref([
  { name: '技术创新部', status: '待审批' },
  { name: '财务部', status: '待审批' },
  { name: '分管领导', status: '待审批' }
])
const currentStep = ref(0)

/**
 * 审批表单
 */
const approvalForm = ref({
  comment: ''
})

/**
 * 审批历史
 */
const approvalHistory = ref([
  { node: '技术创新部', status: '已通过', user: '王主任', comment: '同意立项', time: '2024-03-01 10:00' },
  { node: '财务部', status: '已通过', user: '李会计', comment: '预算合理', time: '2024-03-02 09:30' }
])

const approvalStore = useApprovalStore()
const router = useRouter()

const route = useRoute()
const selectedProjectId = ref('')
onMounted(() => {
  if (route.query.projectId) {
    selectedProjectId.value = route.query.projectId
  }
})

/**
 * 审批通过并自动推进节点
 */
function handleApprove() {
  if (!selectedProjectId.value) {
    message.error('未选中项目')
    return
  }
  // TODO: 同步审批结果至OA系统
  const nextNode = approvalStore.submitAndNext(selectedProjectId.value)
  if (nextNode) {
    message.success(`已进入下一流程节点：${getNodeName(nextNode)}`)
    // 跳转到下一个流程页面
    const nodeRouteMap = {
      materials: '/approval/materials',
      review: '/approval/review',
      decision: '/approval/decision',
      inquiry: '/approval/inquiry'
    }
    router.push({ path: nodeRouteMap[nextNode], query: { projectId: selectedProjectId.value } })
  } else {
    message.success('所有流程已完成！')
  }
}

/**
 * 获取节点中文名
 */
function getNodeName(key) {
  const map = { materials: '申请材料', review: '论证会', decision: '立项审批', inquiry: '询比文件审核' }
  return map[key] || key
}

function handleReject() {
  // TODO: 同步驳回结果至OA系统
  message.error('审批已驳回，已同步OA系统')
}
</script>

<style scoped>
.approval-decision-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}
.header-content {
  flex: 1;
}
.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 24px;
  color: #234fa2;
  margin: 0 0 8px 0;
}
.page-desc {
  color: #64748b;
  margin: 0;
  font-size: 14px;
}
.header-actions {
  display: flex;
  gap: 12px;
}
.flow-section,
.action-section,
.history-section {
  margin-bottom: 24px;
}
</style> 