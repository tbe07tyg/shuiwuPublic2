<template>
  <div class="approval-inquiry-page">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">
          <FileSearchOutlined /> 询比文件审核
        </h1>
        <p class="page-desc">管理和审核招标/询比文件，支持多部门协同与OA流程对接</p>
      </div>
      <div class="header-actions">
        <a-tag color="red">对接OA流程</a-tag>
      </div>
    </div>

    <!-- 招标文件管理区 -->
    <a-card class="file-section" title="招标/询比文件管理">
      <a-table :columns="fileColumns" :data-source="files" rowKey="name" bordered>
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'file'">
            <a-upload
              :file-list="record.fileList"
              :before-upload="file => beforeUpload(file, record)"
              :on-remove="file => onRemove(file, record)"
              :max-count="1"
            >
              <a-button type="link">上传</a-button>
            </a-upload>
          </template>
          <template v-else-if="column.key === 'template'">
            <a-button type="link" @click="downloadTemplate(record)">
              下载模板
            </a-button>
            <!-- 若模板需从外部系统获取，显著标记 -->
            <a-tag v-if="record.fromExternal" color="orange">外部系统获取</a-tag>
          </template>
        </template>
      </a-table>
    </a-card>

    <!-- 多部门协同审核区 -->
    <a-card class="departments-section" title="多部门协同审核">
      <a-table :columns="deptColumns" :data-source="departments" rowKey="name" bordered>
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'status'">
            <a-badge :status="record.status === '已通过' ? 'success' : record.status === '驳回' ? 'error' : 'processing'" :text="record.status" />
          </template>
          <template v-else-if="column.key === 'opinion'">
            <a-input v-model:value="record.opinion" placeholder="请输入审核意见" />
          </template>
        </template>
      </a-table>
      <!-- OA流程节点同步标记 -->
      <a-tag color="red" style="margin-top:8px;">审核状态与OA流程节点同步</a-tag>
    </a-card>

    <!-- OA流程对接区 -->
    <a-card class="oa-section" title="OA流程对接">
      <a-alert
        message="本页面所有审核操作、状态、文件流转均需与OA系统流程同步。"
        type="info"
        show-icon
      />
      <a-tag color="red">对接OA系统流程</a-tag>
      <a-button type="primary" @click="handlePushToOA">推送至OA流程</a-button>
    </a-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { FileSearchOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import { useRoute, useRouter } from 'vue-router'
import { useApprovalStore, nodeOrder } from '@/store/approval'

const route = useRoute()
const router = useRouter()
const approvalStore = useApprovalStore()
const selectedProjectId = ref('')
onMounted(() => {
  if (route.query.projectId) {
    selectedProjectId.value = route.query.projectId
  }
})

/**
 * 招标/询比文件表格列
 */
const fileColumns = [
  { title: '文件名称', dataIndex: 'name', key: 'name' },
  { title: '模板下载', key: 'template', width: 120 },
  { title: '文件上传', key: 'file', width: 180 }
]
const files = ref([
  { name: '招标文件', fileList: [], fromExternal: false },
  { name: '询比文件', fileList: [], fromExternal: false },
  { name: '外部规范文件', fileList: [], fromExternal: true } // 外部系统获取
])
function beforeUpload(file, record) {
  record.fileList = [file]
  return false
}
function onRemove(file, record) {
  record.fileList = []
}
function downloadTemplate(record) {
  if (record.fromExternal) {
    message.info('该模板需从外部系统获取')
  } else {
    message.success('模板下载功能开发中...')
  }
}

/**
 * 多部门协同审核表格列
 */
const deptColumns = [
  { title: '部门', dataIndex: 'name', key: 'name' },
  { title: '审核状态', key: 'status', width: 100 },
  { title: '审核意见', key: 'opinion', width: 200 }
]
const departments = ref([
  { name: '技术创新部', status: '待审核', opinion: '' },
  { name: '财务部', status: '待审核', opinion: '' },
  { name: '招采中心', status: '待审核', opinion: '' },
  { name: '风控法务部', status: '待审核', opinion: '' },
  { name: '分管领导', status: '待审核', opinion: '' }
])

/**
 * 推送至OA流程并自动推进节点
 */
function handlePushToOA() {
  if (!selectedProjectId.value) {
    message.error('未选中项目')
    return
  }
  // TODO: 对接OA系统流程
  const nextNode = approvalStore.submitAndNext(selectedProjectId.value)
  if (nextNode) {
    message.success(`已进入下一流程节点：${getNodeName(nextNode)}`)
    // 跳转到下一个流程页面
    const nodeRouteMap = {
      materials: '/approval/materials',
      review: '/approval/review',
      decision: '/approval/decision',
      inquiry: '/approval/inquiry'
    }
    router.push({ path: nodeRouteMap[nextNode], query: { projectId: selectedProjectId.value } })
  } else {
    message.success('所有流程已完成！')
  }
}

/**
 * 获取节点中文名
 */
function getNodeName(key) {
  const map = { materials: '申请材料', review: '论证会', decision: '立项审批', inquiry: '询比文件审核' }
  return map[key] || key
}
</script>

<style scoped>
.approval-inquiry-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}
.header-content {
  flex: 1;
}
.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 24px;
  color: #234fa2;
  margin: 0 0 8px 0;
}
.page-desc {
  color: #64748b;
  margin: 0;
  font-size: 14px;
}
.header-actions {
  display: flex;
  gap: 12px;
}
.file-section,
.departments-section,
.oa-section {
  margin-bottom: 24px;
}
</style> 