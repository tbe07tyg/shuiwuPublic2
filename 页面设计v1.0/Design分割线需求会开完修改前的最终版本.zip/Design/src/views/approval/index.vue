<template>
  <div class="approval-list-page">
    <!-- 顶部操作区 -->
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">
          <FileTextOutlined /> 项目立项管理清单
        </h1>
        <p class="page-desc">集中管理所有立项申请，快速进入各流程环节</p>
      </div>
      <div class="header-actions">
        <a-button type="primary" @click="showAddModal = true">
          <PlusOutlined /> 新建立项申请
        </a-button>
        <a-button>
          <BarChartOutlined /> 立项数据统计
        </a-button>
        <a-button>
          <CheckSquareOutlined /> 批量审批
        </a-button>
      </div>
    </div>

    <!-- 立项流程导航区 -->
    <a-card class="flow-nav-section" title="立项流程导航">
      <a-steps
        :current="flowSteps.findIndex(n => n.key === currentNode)"
        size="default"
        style="width:100%;"
        @change="onStepChange"
      >
        <a-step
          v-for="node in flowSteps"
          :key="node.key"
          :title="node.title"
        >
          <template #description>
            <a-badge :count="node.count" :number-style="{ backgroundColor: currentNode === node.key ? '#234fa2' : '#d9d9d9' }" />
          </template>
        </a-step>
      </a-steps>
    </a-card>

    <!-- 立项申请清单表格 -->
    <a-card class="list-section" title="立项申请清单">
      <a-table :columns="columns" :data-source="filteredList" rowKey="id" bordered>
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'requirement'">
            <span v-if="record.requirement">
              <a-tag color="blue">{{ record.requirement.title }}</a-tag>
              <span style="color:#999;">({{ record.requirement.priority }}优先级)</span>
            </span>
            <span v-else style="color:#aaa;">未绑定</span>
          </template>
          <template v-else-if="column.key === 'actions'">
            <a-button type="link" @click="editApproval(record)">编辑</a-button>
            <a-button type="link" @click="viewDetail(record)">详情</a-button>
            <a-button type="link" @click="goToNodePage(record)">进入流程</a-button>
          </template>
        </template>
      </a-table>
    </a-card>

    <!-- 新建/编辑立项弹窗 -->
    <a-modal v-model:open="showAddModal" :title="editId ? '编辑立项申请' : '新建立项申请'" @ok="handleSave">
      <a-form :model="formData" layout="vertical">
        <a-form-item label="立项名称" required>
          <a-input v-model:value="formData.title" />
        </a-form-item>
        <a-form-item label="申请人" required>
          <a-input v-model:value="formData.applicant" />
        </a-form-item>
        <a-form-item label="绑定需求" required>
          <a-select v-model:value="formData.requirementId" placeholder="请选择需求">
            <a-select-option v-for="req in requirements" :key="req.id" :value="req.id">{{ req.title }}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="预算(万元)">
          <a-input-number v-model:value="formData.budget" :min="0" style="width:100%" />
        </a-form-item>
        <a-form-item label="状态">
          <a-select v-model:value="formData.status">
            <a-select-option value="待审批">待审批</a-select-option>
            <a-select-option value="已通过">已通过</a-select-option>
            <a-select-option value="已驳回">已驳回</a-select-option>
          </a-select>
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { FileTextOutlined, PlusOutlined, BarChartOutlined, CheckSquareOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import { useRouter } from 'vue-router'
import { useApprovalStore } from '@/store/approval'

/**
 * 立项流程阶段
 */
const flowSteps = ref([
  { key: 'materials', title: '申请材料', count: 0 },
  { key: 'review', title: '论证会', count: 0 },
  { key: 'decision', title: '立项审批', count: 0 },
  { key: 'inquiry', title: '询比文件审核', count: 0 }
])

/**
 * 当前选中节点
 */
const currentNode = ref('materials')

/**
 * 需求池（模拟数据）
 */
const requirements = ref([
  { id: 'REQ001', title: '智能水表需求', priority: '高', proposer: '张三' },
  { id: 'REQ002', title: '管网监测优化', priority: '中', proposer: '李四' }
])

const approvalStore = useApprovalStore()

/**
 * 过滤当前节点下的项目
 */
const filteredList = computed(() => approvalStore.approvalList.filter(a => a.node === currentNode.value))

// 页面加载时初始化节点数量
function updateNodeCounts() {
  flowSteps.value.forEach(node => {
    node.count = approvalStore.approvalList.filter(a => a.node === node.key).length
  })
}
updateNodeCounts()

/**
 * 表格列定义
 */
const columns = [
  { title: '立项名称', dataIndex: 'title', key: 'title' },
  { title: '申请人', dataIndex: 'applicant', key: 'applicant' },
  { title: '预算(万元)', dataIndex: 'budget', key: 'budget' },
  { title: '状态', dataIndex: 'status', key: 'status' },
  { title: '绑定需求', key: 'requirement' },
  { title: '立项节点', dataIndex: 'node', key: 'node',
    customRender: ({ text }) => {
      const map = { materials: '申请材料', review: '论证会', decision: '立项审批', inquiry: '询比文件审核' }
      return map[text] || text
    }
  },
  { title: '操作', key: 'actions' }
]

/**
 * 新建/编辑弹窗相关
 */
const showAddModal = ref(false)
const editId = ref(null)
const formData = ref({ title: '', applicant: '', requirementId: '', budget: 0, status: '待审批' })

/**
 * 需求详情查找
 */
function getRequirementById(id) {
  return requirements.value.find(r => r.id === id)
}

/**
 * 编辑立项
 */
function editApproval(record) {
  editId.value = record.id
  formData.value = { ...record }
  showAddModal.value = true
}

/**
 * 查看详情
 */
function viewDetail(record) {
  message.info('详情功能开发中...')
}

/**
 * 保存立项
 */
function handleSave() {
  if (!formData.value.title || !formData.value.applicant || !formData.value.requirementId) {
    message.error('请填写必填项并绑定需求')
    return
  }
  const req = getRequirementById(formData.value.requirementId)
  if (!req) {
    message.error('请选择有效的需求')
    return
  }
  if (editId.value) {
    // 编辑
    const idx = approvalStore.approvalList.findIndex(a => a.id === editId.value)
    approvalStore.approvalList[idx] = { ...formData.value }
    message.success('立项申请已更新')
  } else {
    // 新增
    approvalStore.approvalList.unshift({ ...formData.value, id: `A${String(approvalStore.approvalList.length + 1).padStart(3, '0')}` })
    message.success('立项申请已创建')
  }
  showAddModal.value = false
  editId.value = null
  formData.value = { title: '', applicant: '', requirementId: '', budget: 0, status: '待审批' }
}

/**
 * 表格数据需求字段补全
 */
approvalStore.approvalList.forEach(a => {
  a.requirement = getRequirementById(a.requirementId)
})

function onStepChange(idx) {
  currentNode.value = flowSteps.value[idx].key
  updateNodeCounts()
}

const router = useRouter()

/**
 * 跳转到对应流程页面并传递projectId
 */
function goToNodePage(record) {
  const nodeRouteMap = {
    materials: '/approval/materials',
    review: '/approval/review',
    decision: '/approval/decision',
    inquiry: '/approval/inquiry'
  }
  const route = nodeRouteMap[record.node]
  if (route) {
    router.push({ path: route, query: { projectId: record.id } })
  }
}
</script>

<style scoped>
.approval-list-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}
.header-content {
  flex: 1;
}
.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 24px;
  color: #234fa2;
  margin: 0 0 8px 0;
}
.page-desc {
  color: #64748b;
  margin: 0;
  font-size: 14px;
}
.header-actions {
  display: flex;
  gap: 12px;
}
.flow-nav-section,
.list-section {
  margin-bottom: 24px;
}
</style> 