<template>
  <div class="approval-materials-page">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">
          <FileAddOutlined /> 立项申请材料管理
        </h1>
        <p class="page-desc">管理立项所需的各类申请材料，支持调研成果导入、材料上传、预算编制与完整性校验</p>
      </div>
      <div class="header-actions">
        <a-button type="primary" @click="handleSubmit">
          <SendOutlined /> 提交审批
        </a-button>
        <!-- OA审批流对接标记 -->
        <a-tag color="red">对接OA审批流</a-tag>
      </div>
    </div>

    <!-- 调研成果导入区（与调研成果模块对接） -->
    <a-card class="import-section" title="调研成果导入">
      <a-alert
        message="可从调研成果库中选择成果，自动填充部分立项材料内容"
        type="info"
        show-icon
      />
      <a-button type="dashed" @click="importFromResearchResults">
        <ImportOutlined /> 导入调研成果
      </a-button>
      <!-- 这里对接调研成果模块 -->
      <a-tag color="blue">对接调研成果模块</a-tag>
      <div v-if="importedResult" class="imported-result-preview">
        <h3>已导入成果：</h3>
        <div>标题：{{ importedResult.title }}</div>
        <div>主要结论：{{ importedResult.summary }}</div>
        <div>建议预算：{{ importedResult.budget }}</div>
      </div>
    </a-card>

    <!-- 材料上传与管理区 -->
    <a-card class="materials-section" title="申请材料上传与管理">
      <a-table :columns="materialColumns" :data-source="materials" rowKey="name" bordered>
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'file'">
            <a-upload
              :file-list="record.fileList"
              :before-upload="file => beforeUpload(file, record)"
              :on-remove="file => onRemove(file, record)"
              :max-count="1"
            >
              <a-button type="link">上传</a-button>
            </a-upload>
          </template>
          <template v-else-if="column.key === 'template'">
            <a-button type="link" @click="downloadTemplate(record)">
              下载模板
            </a-button>
            <!-- 若模板需从外部系统获取，显著标记 -->
            <a-tag v-if="record.fromExternal" color="orange">外部系统获取</a-tag>
          </template>
        </template>
      </a-table>
    </a-card>

    <!-- 预算编制器区（对接用友财务系统） -->
    <a-card class="budget-section" title="预算编制器">
      <a-alert
        message="可编辑预算明细，支持导入/导出Excel。预算数据可与用友财务系统对接。"
        type="info"
        show-icon
      />
      <a-tag color="red">对接用友财务系统</a-tag>
      <a-table :columns="budgetColumns" :data-source="budgetData" bordered size="small" />
      <div class="budget-actions">
        <a-button @click="importBudgetExcel">导入Excel</a-button>
        <a-button @click="exportBudgetExcel">导出Excel</a-button>
      </div>
    </a-card>

    <!-- 材料完整性校验区 -->
    <a-card class="integrity-section" title="材料完整性校验">
      <a-alert
        :message="integrityMessage"
        :type="integrityStatus === '完整' ? 'success' : 'warning'"
        show-icon
      />
      <a-list :data-source="integrityList" bordered>
        <template #renderItem="{ item }">
          <a-list-item>
            <a-badge :status="item.status === '已上传' ? 'success' : 'error'" :text="item.name + ' - ' + item.status" />
          </a-list-item>
        </template>
      </a-list>
    </a-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import {
  FileAddOutlined,
  SendOutlined,
  ImportOutlined
} from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import { useRoute, useRouter } from 'vue-router'
import { useApprovalStore, nodeOrder } from '@/store/approval'

/**
 * 申请材料表格列定义
 */
const materialColumns = [
  { title: '材料名称', dataIndex: 'name', key: 'name' },
  { title: '模板下载', key: 'template', width: 120 },
  { title: '文件上传', key: 'file', width: 180 }
]

/**
 * 预算表格列定义
 */
const budgetColumns = [
  { title: '预算科目', dataIndex: 'subject', key: 'subject' },
  { title: '金额(元)', dataIndex: 'amount', key: 'amount', editable: true }
]

/**
 * 材料数据
 */
const materials = ref([
  { name: '科技研发项目申报书', fileList: [], fromExternal: false },
  { name: '科技研发项目预算', fileList: [], fromExternal: false },
  { name: '科技研发项目立项PPT', fileList: [], fromExternal: false },
  { name: '下年度计划文件', fileList: [], fromExternal: true } // 外部系统获取
])

/**
 * 预算数据
 */
const budgetData = ref([
  { subject: '人员经费', amount: 0 },
  { subject: '设备购置', amount: 0 },
  { subject: '材料费', amount: 0 },
  { subject: '差旅费', amount: 0 }
])

/**
 * 完整性校验数据
 */
const integrityList = ref([
  { name: '科技研发项目申报书', status: '未上传' },
  { name: '科技研发项目预算', status: '未上传' },
  { name: '科技研发项目立项PPT', status: '未上传' },
  { name: '下年度计划文件', status: '未上传' }
])
const integrityStatus = ref('不完整')
const integrityMessage = ref('请上传所有必需材料')

/**
 * 已导入调研成果
 */
const importedResult = ref(null)

/**
 * 导入调研成果
 */
function importFromResearchResults() {
  // TODO: 对接调研成果模块，弹窗选择成果
  message.info('调研成果导入功能开发中...')
}

/**
 * 上传文件前校验
 */
function beforeUpload(file, record) {
  // TODO: 文件类型/大小校验
  record.fileList = [file]
  updateIntegrity(record.name, '已上传')
  return false // 阻止自动上传，实际应由后端接口处理
}

/**
 * 移除文件
 */
function onRemove(file, record) {
  record.fileList = []
  updateIntegrity(record.name, '未上传')
}

/**
 * 下载模板
 */
function downloadTemplate(record) {
  if (record.fromExternal) {
    message.info('该模板需从外部系统获取')
  } else {
    message.success('模板下载功能开发中...')
  }
}

/**
 * 预算Excel导入导出
 */
function importBudgetExcel() {
  // TODO: 对接Excel导入
  message.info('预算Excel导入功能开发中...')
}
function exportBudgetExcel() {
  // TODO: 对接Excel导出
  message.info('预算Excel导出功能开发中...')
}

/**
 * 更新完整性校验
 */
function updateIntegrity(name, status) {
  const item = integrityList.value.find(i => i.name === name)
  if (item) item.status = status
  integrityStatus.value = integrityList.value.every(i => i.status === '已上传') ? '完整' : '不完整'
  integrityMessage.value = integrityStatus.value === '完整' ? '所有材料已上传，可提交审批' : '请上传所有必需材料'
}

/**
 * 提交审批并自动推进节点
 */
function handleSubmit() {
  if (integrityStatus.value !== '完整') {
    message.error('请先上传所有必需材料')
    return
  }
  if (!selectedProjectId.value) {
    message.error('未选中项目')
    return
  }
  const nextNode = approvalStore.submitAndNext(selectedProjectId.value)
  if (nextNode) {
    message.success(`已进入下一流程节点：${getNodeName(nextNode)}`)
    // 跳转到下一个流程页面
    const nodeRouteMap = {
      materials: '/approval/materials',
      review: '/approval/review',
      decision: '/approval/decision',
      inquiry: '/approval/inquiry'
    }
    router.push({ path: nodeRouteMap[nextNode], query: { projectId: selectedProjectId.value } })
  } else {
    message.success('所有流程已完成！')
  }
}

/**
 * 获取节点中文名
 */
function getNodeName(key) {
  const map = { materials: '申请材料', review: '论证会', decision: '立项审批', inquiry: '询比文件审核' }
  return map[key] || key
}

const approvalStore = useApprovalStore()
const router = useRouter()
const route = useRoute()
const selectedProjectId = ref('')
onMounted(() => {
  if (route.query.projectId) {
    selectedProjectId.value = route.query.projectId
  }
})
</script>

<style scoped>
.approval-materials-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}
.header-content {
  flex: 1;
}
.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 24px;
  color: #234fa2;
  margin: 0 0 8px 0;
}
.page-desc {
  color: #64748b;
  margin: 0;
  font-size: 14px;
}
.header-actions {
  display: flex;
  gap: 12px;
}
.import-section,
.materials-section,
.budget-section,
.integrity-section {
  margin-bottom: 24px;
}
.imported-result-preview {
  margin-top: 12px;
  background: #f8fafc;
  padding: 12px;
  border-radius: 6px;
}
.budget-actions {
  margin-top: 12px;
  display: flex;
  gap: 12px;
}
</style> 