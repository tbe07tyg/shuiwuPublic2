<template>
  <div class="implementation-payment-page">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">
          <PayCircleOutlined /> 付款管理
        </h1>
        <p class="page-desc">基于节点进度进行付款管理，集成用友系统与资金分析</p>
      </div>
      <div class="header-actions">
        <a-select v-model:value="selectedProject" placeholder="选择项目" style="width: 220px; margin-right: 12px;" @change="handleProjectChange">
          <a-select-option v-for="project in projects" :key="project.id" :value="project.id">{{ project.name }}</a-select-option>
        </a-select>
        <a-tag color="red">对接用友系统</a-tag>
      </div>
    </div>

    <!-- 付款节点状态与进度跟踪区 -->
    <a-card class="node-status-section" title="付款节点状态">
      <a-steps :current="currentStep" direction="horizontal">
        <a-step v-for="(node, idx) in paymentNodes" :key="node.id" :title="node.name" :description="node.status" />
      </a-steps>
      <a-progress :percent="progressPercent" style="margin-top:16px;" />
    </a-card>

    <!-- 付款申请区（对接用友系统） -->
    <a-card class="apply-section" title="付款申请">
      <a-form :model="applyForm" layout="inline">
        <a-form-item label="付款类型">
          <a-radio-group v-model:value="applyForm.type">
            <a-radio value="node">节点型付款</a-radio>
            <a-radio value="purchase">采购型付款</a-radio>
          </a-radio-group>
        </a-form-item>
        <template v-if="applyForm.type === 'node'">
          <a-form-item label="付款节点">
            <a-select v-model:value="applyForm.nodeId" style="width: 180px" @change="onNodeChange">
              <a-select-option v-for="node in paymentNodes" :key="node.id" :value="node.id">{{ node.name }}</a-select-option>
            </a-select>
          </a-form-item>
          <a-form-item label="合同">
            <div v-if="mainContract">
              <span>{{ mainContract.name }}</span>
              <a-button type="link" @click="downloadContract(mainContract)">下载</a-button>
              <a-upload :before-upload="beforeUploadNodeContract" :file-list="contractFileList" :on-remove="onRemoveNodeContract" :max-count="1">
                <a-button type="link">重新上传</a-button>
              </a-upload>
            </div>
            <div v-else>
              <a-upload :before-upload="beforeUploadNodeContract" :file-list="contractFileList" :on-remove="onRemoveNodeContract" :max-count="1">
                <a-button>上传合同</a-button>
              </a-upload>
            </div>
          </a-form-item>
          <a-form-item label="申请金额">
            <a-input-number v-model:value="applyForm.amount" :min="0" style="width: 120px" disabled />
          </a-form-item>
        </template>
        <template v-else>
          <a-form-item label="付款名目">
            <a-input v-model:value="applyForm.title" style="width: 120px" />
          </a-form-item>
          <a-form-item label="资金来源">
            <a-select v-model:value="applyForm.categoryId" style="width: 140px">
              <a-select-option v-for="cat in budgetCategories" :key="cat.id" :value="cat.id">{{ cat.name }}</a-select-option>
            </a-select>
          </a-form-item>
          <a-form-item label="合同">
            <a-upload :before-upload="beforeUploadPurchaseContract" :file-list="applyForm.contractFileList" :on-remove="onRemovePurchaseContract" :max-count="1">
              <a-button>上传合同</a-button>
            </a-upload>
          </a-form-item>
          <a-form-item label="申请金额">
            <a-input-number v-model:value="applyForm.amount" :min="0" style="width: 120px" />
          </a-form-item>
        </template>
        <a-form-item>
          <a-button type="primary" @click="handleApply">提交申请</a-button>
        </a-form-item>
      </a-form>
      <a-tag color="red" style="margin-top:8px;">付款申请与用友系统同步</a-tag>
    </a-card>

    <!-- 资金使用分析区 -->
    <a-card class="analysis-section" title="资金使用分析">
      <a-alert message="资金分析与用友系统数据对接" type="info" show-icon />
      <a-table :columns="analysisColumns" :data-source="analysisData" bordered style="margin-top:16px;" />
    </a-card>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { PayCircleOutlined } from '@ant-design/icons-vue'
import { message } from 'ant-design-vue'
import { useImplementationStore } from '@/store/implementation'

const implementationStore = useImplementationStore()

/**
 * 付款节点状态
 */
const paymentNodes = ref([])
const currentStep = computed(() => paymentNodes.value.findIndex(n => n.status === '进行中'))
const progressPercent = computed(() => {
  const total = paymentNodes.value.length
  const done = paymentNodes.value.filter(n => n.status === '已完成').length
  return Math.round((done / total) * 100)
})

/**
 * 付款申请表单
 */
const budgetCategories = ref([
  { id: 'B1', name: '设备采购' },
  { id: 'B2', name: '材料费' },
  { id: 'B3', name: '服务费' }
])
const applyForm = ref({
  type: 'node',
  nodeId: '',
  contract: '',
  amount: 0,
  title: '',
  categoryId: '',
  contractFileList: []
})
function onNodeChange(val) {
  // mock: 根据节点自动带出合同和金额
  const node = paymentNodes.value.find(n => n.id === val)
  if (node) {
    applyForm.value.amount = node.id === 'N1' ? 300000 : node.id === 'N2' ? 400000 : 300000
    applyForm.value.contract = '项目主合同'
  }
}
function beforeUploadNodeContract(file) {
  contractFileList.value = [file]
  return false
}
function onRemoveNodeContract(file) {
  contractFileList.value = []
}
function handleApply() {
  if (applyForm.value.type === 'node') {
    if (!applyForm.value.nodeId) return message.error('请选择付款节点')
    message.success('节点型付款申请已提交（同步用友系统）')
  } else {
    if (!applyForm.value.title || !applyForm.value.categoryId) return message.error('请填写名目和资金来源')
    message.success('采购型付款申请已提交（同步用友系统）')
  }
}

/**
 * 资金分析
 */
const analysisColumns = [
  { title: '节点', dataIndex: 'node', key: 'node' },
  { title: '应付金额', dataIndex: 'shouldPay', key: 'shouldPay' },
  { title: '已付金额', dataIndex: 'paid', key: 'paid' },
  { title: '剩余金额', dataIndex: 'remain', key: 'remain' }
]
const analysisData = ref([
  { node: '首付款', shouldPay: 300000, paid: 300000, remain: 0 },
  { node: '中期款', shouldPay: 400000, paid: 200000, remain: 200000 },
  { node: '尾款', shouldPay: 300000, paid: 0, remain: 300000 }
])

/**
 * 项目数据与逻辑
 */
const projects = ref([
  { id: 'P001', name: '项目A' },
  { id: 'P002', name: '项目B' }
])
const selectedProject = ref()
function handleProjectChange(value) {
  console.log('当前选择项目:', value)
  // 从store加载节点配置
  const nodes = implementationStore.getProjectNodes(value)
  if (nodes && nodes.length) {
    paymentNodes.value = nodes.map(node => ({
      ...node,
      status: node.status || '未开始'
    }))
  } else {
    paymentNodes.value = []
    message.warning('该项目未配置节点，请先在节点管理中心配置')
  }
}

// mock: 合同管理中已上传合同
const mainContract = ref({ name: '项目主合同.pdf', url: '/mock/contract.pdf' })
const contractFileList = ref([])
function downloadContract(contract) {
  window.open(contract.url, '_blank')
}

function beforeUploadPurchaseContract(file) {
  applyForm.value.contractFileList = [file]
  return false
}
function onRemovePurchaseContract(file) {
  applyForm.value.contractFileList = []
}
</script>

<style scoped>
.implementation-payment-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}
.header-content {
  flex: 1;
}
.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 24px;
  color: #234fa2;
  margin: 0 0 8px 0;
}
.page-desc {
  color: #64748b;
  margin: 0;
  font-size: 14px;
}
.header-actions {
  display: flex;
  gap: 12px;
}
.node-status-section,
.apply-section,
.analysis-section {
  margin-bottom: 24px;
}
</style> 