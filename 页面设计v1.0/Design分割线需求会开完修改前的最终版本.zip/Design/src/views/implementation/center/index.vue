<template>
  <div class="implementation-center-page">
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">项目实施管理中心</h1>
        <p class="page-desc">集中观察所有实施项目的进展、状态与各环节管理</p>
      </div>
    </div>
    <a-card class="list-section" title="项目实施项目列表">
      <a-table :columns="columns" :data-source="projectList" rowKey="id" bordered>
        <template #bodyCell="{ column, record }">
          <template v-if="column.key === 'progress'">
            <a-progress :percent="record.progress" size="small" />
          </template>
          <template v-else-if="column.key === 'payment'">
            <a-badge :status="record.paymentStatus === '已完成' ? 'success' : 'processing'" :text="record.paymentStatus" />
          </template>
          <template v-else-if="column.key === 'actions'">
            <a-space>
              <a-button type="link" @click="goTo('contract', record)">合同管理</a-button>
              <a-button type="link" @click="goTo('node', record)">节点管理中心</a-button>
              <a-button type="link" @click="goTo('payment', record)">付款管理</a-button>
              <a-button type="link" @click="goTo('progress', record)">进度管理</a-button>
              <a-button type="link" @click="goTo('acceptance', record)">项目验收</a-button>
              <span v-if="record.nodeConfigured" style="color: #52c41a; font-size: 12px;">已配置节点</span>
            </a-space>
          </template>
        </template>
      </a-table>
    </a-card>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useApprovalStore } from '@/store/approval'
import { useRouter } from 'vue-router'

/**
 * 表格列定义
 */
const columns = [
  { title: '项目名称', dataIndex: 'title', key: 'title' },
  { title: '负责人', dataIndex: 'applicant', key: 'applicant' },
  { title: '当前进度', key: 'progress' },
  { title: '状态', dataIndex: 'status', key: 'status' },
  { title: '付款状态', key: 'payment' },
  { title: '操作', key: 'actions' }
]

const approvalStore = useApprovalStore()

/**
 * 项目实施管理中心数据源：所有已通过立项审批的项目
 * @type {import('vue').ComputedRef<Array>}
 */
const projectList = computed(() =>
  approvalStore.approvalList
    .filter(p => (p.status === '已通过' && (p.node === 'decision' || p.node === 'inquiry')))
    .map(p => ({
      ...p,
      progress: p.progress ?? 60, // mock进度
      paymentStatus: p.paymentStatus ?? '进行中' // mock付款状态
    }))
)

const router = useRouter()

/**
 * 跳转到二级页面
 * @param {string} type
 * @param {object} record
 */
function goTo(type, record) {
  const routeMap = {
    contract: '/implementation/contract',
    node: '/implementation/node',
    payment: '/implementation/payment',
    progress: '/implementation/progress',
    acceptance: '/implementation/acceptance'
  }
  const path = routeMap[type]
  if (path) {
    router.push({ path, query: { projectId: record.id } })
  }
}
</script>

<style scoped>
.implementation-center-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}
.page-header {
  display: flex;
  align-items: flex-start;
  margin-bottom: 24px;
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}
.header-content {
  flex: 1;
}
.page-title {
  font-size: 24px;
  color: #234fa2;
  margin: 0 0 8px 0;
}
.page-desc {
  color: #64748b;
  margin: 0;
  font-size: 14px;
}
.list-section {
  margin-bottom: 24px;
}
</style> 