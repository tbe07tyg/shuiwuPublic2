<template>
  <div class="implementation-progress-page">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-content">
        <h1 class="page-title">
          <LineChartOutlined /> 进度监控
        </h1>
        <p class="page-desc">实时监控项目进度，节点状态、里程碑与风险预警一目了然</p>
      </div>
      <div class="header-actions">
        <a-select v-model:value="selectedProject" placeholder="选择项目" style="width: 220px; margin-right: 12px;" @change="handleProjectChange">
          <a-select-option v-for="project in projects" :key="project.id" :value="project.id">{{ project.name }}</a-select-option>
        </a-select>
      </div>
    </div>

    <!-- 项目进度总览区 -->
    <a-card class="overview-section" title="项目进度总览">
      <a-progress :percent="projectPercent" status="active" />
      <div style="margin-top:12px;">当前进度：{{ projectPercent }}%</div>
    </a-card>

    <!-- 节点进度区 -->
    <a-card class="nodes-section" title="节点进度">
      <a-steps :current="currentStep" direction="horizontal">
        <a-step v-for="(node, idx) in nodes" :key="node.id" :title="node.name" :description="node.status" />
      </a-steps>
    </a-card>

    <!-- 里程碑区 -->
    <a-card class="milestone-section" title="里程碑">
      <a-timeline>
        <a-timeline-item v-for="m in milestones" :key="m.id" :color="m.status === '已完成' ? 'green' : m.status === '预警' ? 'red' : 'blue'">
          <div>
            <b>{{ m.name }}</b> - {{ m.status }}
            <span style="float:right; color:#999">{{ m.date }}</span>
          </div>
          <div>{{ m.desc }}</div>
        </a-timeline-item>
      </a-timeline>
    </a-card>

    <!-- 风险预警区 -->
    <a-card class="risk-section" title="风险预警">
      <a-alert v-if="risks.length === 0" message="暂无风险预警" type="success" show-icon />
      <a-list v-else :data-source="risks" bordered>
        <template #renderItem="{ item }">
          <a-list-item>
            <a-badge status="error" :text="item.title + ' - ' + item.level" />
            <span style="margin-left:16px; color:#999">{{ item.desc }}</span>
          </a-list-item>
        </template>
      </a-list>
    </a-card>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { LineChartOutlined } from '@ant-design/icons-vue'
import { useImplementationStore } from '@/store/implementation'

const implementationStore = useImplementationStore()

/**
 * 项目进度总览
 */
const nodes = ref([])
const currentStep = computed(() => nodes.value.findIndex(n => n.status === '进行中'))
const projectPercent = computed(() => {
  const total = nodes.value.length
  const done = nodes.value.filter(n => n.status === '已完成').length
  return Math.round((done / total) * 100)
})

/**
 * 里程碑
 */
const milestones = ref([])

/**
 * 风险预警
 */
const risks = ref([])

const projects = ref([
  { id: 'P001', name: '项目A' },
  { id: 'P002', name: '项目B' }
])
const selectedProject = ref()

function handleProjectChange(value) {
  console.log('当前选择项目:', value)
  // 从store加载节点配置
  const projectNodes = implementationStore.getProjectNodes(value)
  if (projectNodes && projectNodes.length) {
    nodes.value = projectNodes.map(node => ({
      ...node,
      status: node.status || '未开始'
    }))
    
    // 根据节点生成里程碑
    milestones.value = nodes.value.map((node, index) => ({
      id: `M${index + 1}`,
      name: node.name,
      status: node.status === '已完成' ? '已完成' : node.status === '进行中' ? '进行中' : '未完成',
      date: new Date(Date.now() + index * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      desc: node.condition || '计划中'
    }))
    
    // 检查风险
    risks.value = []
    const delayedNodes = nodes.value.filter(n => n.status === '进行中' && n.percent < 50)
    if (delayedNodes.length) {
      risks.value.push({
        title: '节点进度滞后',
        level: '高',
        desc: `${delayedNodes.map(n => n.name).join('、')}等节点进度滞后`
      })
    }
  } else {
    nodes.value = []
    milestones.value = []
    risks.value = []
    message.warning('该项目未配置节点，请先在节点管理中心配置')
  }
}
</script>

<style scoped>
.implementation-progress-page {
  padding: 24px;
  background: #f5f7fa;
  min-height: 100vh;
}
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
  background: #fff;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(35,79,162,0.06);
}
.header-content {
  flex: 1;
}
.page-title {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 24px;
  color: #234fa2;
  margin: 0 0 8px 0;
}
.page-desc {
  color: #64748b;
  margin: 0;
  font-size: 14px;
}
.header-actions {
  display: flex;
  gap: 12px;
}
.overview-section,
.nodes-section,
.milestone-section,
.risk-section {
  margin-bottom: 24px;
}
</style> 