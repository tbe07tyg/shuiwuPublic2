<template>
  <div class="stat-card2" :style="{background:colorBg}">
    <div class="stat-card2-main">
      <div class="stat-card2-value">{{ value }}</div>
      <div class="stat-card2-title">{{ type }}</div>
    </div>
    <div class="stat-card2-progress">
      <a-progress
        type="circle"
        :percent="percent"
        :width="64"
        :strokeColor="color"
      >
        <template #format>
          <component :is="iconComponent" :style="{fontSize:'32px',color:color}" />
        </template>
      </a-progress>
    </div>
  </div>
</template>
<script setup>
import { computed } from 'vue'
import { AppstoreOutlined, ProjectOutlined, FileTextOutlined, SettingOutlined, UserOutlined } from '@ant-design/icons-vue'
/**
 * @typedef StatCardProps
 * @property {string} icon - 图标名
 * @property {string} color - 主色
 * @property {number} value - 数字
 * @property {string} type - 类型
 * @property {number} [percent] - 进度百分比
 */
const props = defineProps({
  icon: String,
  color: String,
  value: Number,
  type: String,
  percent: { type: Number, default: 80 },
})
const iconMap = {
  UserOutlined,
  ProjectOutlined,
  FileTextOutlined,
  SettingOutlined,
  AppstoreOutlined,
}
const iconComponent = computed(() => iconMap[props.icon] || AppstoreOutlined)
const colorBg = computed(() => {
  // 根据主色生成渐变背景
  if (props.color === '#234fa2') return 'linear-gradient(135deg,#eaf0fa 0%,#f5f8ff 100%)'
  if (props.color === '#faad14') return 'linear-gradient(135deg,#fff7e6 0%,#f5f8ff 100%)'
  if (props.color === '#ff4d4f') return 'linear-gradient(135deg,#fff1f0 0%,#f5f8ff 100%)'
  if (props.color === '#52c41a' || props.color === '#87d068') return 'linear-gradient(135deg,#f6ffed 0%,#f5f8ff 100%)'
  if (props.color === '#2db7f5') return 'linear-gradient(135deg,#e6f7ff 0%,#f5f8ff 100%)'
  return '#f5f8ff'
})
</script>
<style scoped>
.stat-card2 {
  border-radius: 16px;
  box-shadow: 0 8px 36px rgba(35,79,162,0.20);
  display: flex;
  align-items: center;
  padding: 18px 32px 18px 24px;
  min-width: 240px;
  flex: 1;
  background: #f5f8ff;
  justify-content: space-between;
  gap: 32px;
}
.stat-card2-main {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1;
}
.stat-card2-progress {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.stat-card2-title {
  font-size: 15px;
  color: #234fa2;
  font-weight: 600;
  margin-top: 2px;
}
.stat-card2-value {
  font-size: 32px;
  font-weight: bold;
  color: #234fa2;
}
</style> 