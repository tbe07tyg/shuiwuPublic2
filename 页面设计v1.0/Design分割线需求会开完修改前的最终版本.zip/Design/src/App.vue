<template>
  <router-view />
  <AIHelperDrawer />
</template>

<script setup>
import AIHelperDrawer from '@/components/AIHelperDrawer.vue'
</script>

<style>
body {
  margin: 0;
  font-family: 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', Arial, sans-serif;
  background: #f5f5f5;
}
</style> 